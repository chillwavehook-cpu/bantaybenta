import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";




// ═══════════════════════════════════════════════ COLORS
const C = {
  bg0:"#06080e", bg1:"#0c0f18", bg2:"#111520", bg3:"#181d2e", bg4:"#1e2438",
  b:"#1c2235", b2:"#263050",
  tx:"#e0e8ff", d2:"#6b7a9e", d3:"#35405a",
  gr:"#22d3a0", gd:"#071f17",
  re:"#ff6b6b", rd:"#2a0a0a",
  am:"#f5a623", ad:"#261500",
  bl:"#4d9eff", bd:"#071428",
  pu:"#a78bfa", pd:"#110e26",
  cy:"#22d3ee", cd:"#061820",
  ac:"#2563eb",
};

// ═══════════════════════════════════════════════ LIGHTWEIGHT DB
const DB = {
  _p: "bb4_",
  get(k, d) { try { const v = localStorage.getItem(this._p+k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(this._p+k, JSON.stringify(v)); this._touch(); return true; } catch(e) { if(e.name==="QuotaExceededError"){ this._evict(); try{ localStorage.setItem(this._p+k,JSON.stringify(v)); return true; }catch{ return false; } } return false; } },
  _touch() { localStorage.setItem(this._p+"_ts", Date.now()); },
  _evict() { const abs = this.get("auto_bk",[]); this.set("auto_bk", abs.slice(0,8)); },
  PAGE: 50,
  getSalesPage(page=0) { const all = this.get("sales",[]); const start = Math.max(0, all.length - (page+1)*this.PAGE); const end = all.length - page*this.PAGE; return { items: all.slice(start,end).reverse(), total: all.length, pages: Math.ceil(all.length/this.PAGE) || 1 }; },
  getAllSales() { return this.get("sales",[]); },
  addSale(s) { const all = this.get("sales",[]); all.push(s); this.set("sales",all); },
  toggleSalePaid(id,paid) { const all=this.get("sales",[]); const i=all.findIndex(s=>s.id===id); if(i>=0){all[i].paid=paid;this.set("sales",all);} },
  addPartialPayment(id,amount) { const all=this.get("sales",[]); const i=all.findIndex(s=>s.id===id); if(i>=0){ const s=all[i]; s.partialPaid=(s.partialPaid||0)+amount; s.paid=s.partialPaid>=s.total; this.set("sales",all); } },
  updateSale(id,patch) { const all = this.get("sales",[]); const i=all.findIndex(s=>s.id===id); if(i>=0){all[i]={...all[i],...patch};this.set("sales",all);} },
  sizeKB() { try{ let b=0; Object.keys(localStorage).filter(k=>k.startsWith(this._p)).forEach(k=>{ b+=(localStorage.getItem(k)||"").length*2; }); return (b/1024).toFixed(1); }catch{return"0";} },
  lastSaved() { const t=localStorage.getItem(this._p+"_ts"); return t?new Date(Number(t)).toLocaleTimeString("en-PH"):null; },
  snapshot() { const keys=["products","sales","expenses","categories","stock_purchases"]; const d={}; keys.forEach(k=>{d[k]=this.get(k,null);}); return d; },
  restore(data) { try{ Object.entries(data).forEach(([k,v])=>this.set(k,v)); return true; }catch{return false;} },
  saveBackup(label) { const snap=this.snapshot(); const e={id:Date.now(),label:label||"Backup — "+new Date().toLocaleString("en-PH"),ts:new Date().toISOString(),data:snap,kb:(JSON.stringify(snap).length/1024).toFixed(1)}; const l=this.get("backups",[]); this.set("backups",[e,...l].slice(0,30)); return e; },
  autoBackup() { const snap=this.snapshot(); if(!snap.products&&!snap.sales)return; const e={id:Date.now(),ts:new Date().toISOString(),data:snap,kb:(JSON.stringify(snap).length/1024).toFixed(1)}; const l=this.get("auto_bk",[]); this.set("auto_bk",[e,...l].slice(0,48)); this.set("last_ab",Date.now()); },
  addStockPurchase(sp) {
    const all = this.get("stock_purchases",[]);
    all.push({...sp, id:Date.now().toString(36)});
    this.set("stock_purchases", all);
  },
  getStockPurchases() { return this.get("stock_purchases",[]); },
  download(backup) { const b=new Blob([JSON.stringify(backup,null,2)],{type:"application/json"}); const u=URL.createObjectURL(b); const a=document.createElement("a"); a.href=u; a.download="bantaybenta-backup-"+backup.id+".json"; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(u); },
};

// ═══════════════════════════════════════════════ SEEDS
const DEF_CATS = ["Pagkain","Inumin","Gamit","Kagamitan","Panghimagas","Iba pa"];
const CAT_COLORS = ["#22d3a0","#4d9eff","#f5a623","#ff6b6b","#a78bfa","#22d3ee","#f472b6","#84cc16"];
// Maps tingi unit → pack container name
const PACK_UNIT_MAP = {
  "piraso": "pack", "stick": "ream", "sachet": "box",
  "supot": "bundle", "kilo": "sack", "gramo": "box",
  "liter": "case", "ml": "case", "bote": "case",
  "lata": "case", "pack": "case", "box": "case",
  "tali": "bundle", "dosena": "gross", "sukat": "pack",
};
// Pack container labels
const PACK_CONTAINERS = [
  {val:"pack",  label:"Pack"},
  {val:"case",  label:"Case"},
  {val:"ream",  label:"Ream"},
  {val:"sack",  label:"Sack"},
  {val:"bundle",label:"Bundle"},
  {val:"box",   label:"Box"},
  {val:"gross", label:"Gross (144 pcs)"},
  {val:"strip", label:"Strip"},
  {val:"tray",  label:"Tray"},
  {val:"bag",   label:"Bag"},
];
const getPackLabel = (p) => {
  // Use product's packType if set, else guess from unit
  if(p.packType && p.packType!=="pack") return p.packType;
  return PACK_UNIT_MAP[p.unit||"piraso"] || "pack";
};

const TINGI_UNITS = [
  {val:"piraso",   label:"Piraso (piece)"},
  {val:"stick",    label:"Stick (sigarilyo, etc)"},
  {val:"sachet",   label:"Sachet"},
  {val:"supot",    label:"Supot / Plastic bag"},
  {val:"kilo",     label:"Kilo"},
  {val:"gramo",    label:"Gramo"},
  {val:"liter",    label:"Liter"},
  {val:"ml",       label:"Milliliter"},
  {val:"bote",     label:"Bote"},
  {val:"lata",     label:"Lata / Can"},
  {val:"pack",     label:"Pack"},
  {val:"box",      label:"Box"},
  {val:"tali",     label:"Tali / Bundle"},
  {val:"dosena",   label:"Dosena (12 pcs)"},
  {val:"sukat",    label:"Sukat / Serving"},
];
const SEED_PRODUCTS = [];
const SEED_SALES    = [];
const SEED_EXP      = [];

// ═══════════════════════════════════════════════ HELPERS
const P   = n => "₱"+Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",");
const td  = ()  => new Date().toISOString().slice(0,10);
const wk  = ()  => { const d=new Date(); d.setDate(d.getDate()-d.getDay()); return d.toISOString().slice(0,10); };
const mo  = ()  => new Date().toISOString().slice(0,7)+"-01";
const uid = ()  => Date.now().toString(36)+Math.random().toString(36).slice(2,6);

const USERS = [
  {id:1,name:"Store Owner",role:"owner",    pin:"0000",emoji:"🏪",color:C.gr},
  {id:2,name:"Admin",      role:"admin",    pin:"1234",emoji:"⚙️",color:C.bl},
  {id:3,name:"Developer",  role:"developer",pin:"5678",emoji:"🛠️",color:C.pu},
];

// ═══════════════════════════════════════════════ TRANSLATIONS
const TR = {
  tl:{
    app:"Bantay Benta",sub:"Mabilis na Tindahan",
    login:"Pumasok",selAcc:"Piliin ang Account",pin:"PIN Code",demo:"Demo: Owner=0000 · Admin=1234 · Dev=5678",wrongPin:"Mali ang PIN.",
    dash:"Dashboard",sales:"Benta",pay:"Utang",inv:"Imbentaryo",cats:"Kategorya",reorder:"Mag-order",exp:"Gastos",rep:"Ulat",bk:"Backup",
    adm:"Admin",bugs:"Bugs",ai:"AI Help",
    quickSale:"⚡ Quick Sale",newSale:"+ Bagong Benta",addProd:"+ Produkto",addExp:"+ Gastos",addCat:"+ Kategorya",
    totalRev:"Kabuuang Kita",todaySales:"Benta Ngayon",unpaidBal:"Hindi pa Bayad",netProfit:"Netong Tubo",
    paid:"Bayad",unpaid:"Utang",all:"Lahat",save:"I-save",cancel:"Kanselahin",
    cust:"Customer",date:"Petsa",total:"Kabuuan",method:"Paraan",status:"Status",
    prod:"Produkto",cat:"Kategorya",price:"Presyo",cost:"Puhunan",stock:"Stock",
    reorderAt:"Min",orderQty:"Order Qty",note:"Tala",amt:"Halaga",unit:"Unit",
    inc:"Kita",exp2:"Gastos",profit:"Tubo",search:"🔍 Maghanap...",
    markPaid:"Bayad na ✓",payHist:"Kasaysayan ng Bayad",recSales:"Pinakabagong Benta",
    allSettled:"Lahat ay bayad! 🎉",allStocked:"Sapat ang lahat ✅",
    daily:"Araw",weekly:"Linggo",monthly:"Buwan",
    today:"Ngayon",thisWeek:"Linggong ito",thisMonth:"Buwang ito",
    topProds:"Top Products",expBrk:"Breakdown ng Gastos",
    logout:"Lumabas",lang:"English",
    bkNow:"Mag-Backup",createBk:"Gumawa ng Backup",restoreFile:"I-Restore",
    autoBk:"Auto Backups",manBk:"Manual Backups",
    adj:"Ayos",reorderList:"Listahan ng Mag-order",shortage:"Kulang",estCost:"Est. Cost",
    pri:"Priority",critical:"Kritikal",high:"Mataas",medium:"Katamtaman",
    duplicate:"Kopyahin",edit:"I-edit",delete:"Burahin",
    catName:"Pangalan ng Kategorya",catColor:"Kulay",sku:"SKU",
  },
  en:{
    app:"Bantay Benta",sub:"Fast Store Manager",
    login:"Login",selAcc:"Select Account",pin:"PIN Code",demo:"Demo: Owner=0000 · Admin=1234 · Dev=5678",wrongPin:"Wrong PIN.",
    dash:"Dashboard",sales:"Sales",pay:"Payments",inv:"Inventory",cats:"Categories",reorder:"Reorder",exp:"Expenses",rep:"Reports",bk:"Backup",
    adm:"Admin",bugs:"Bugs",ai:"AI Help",
    quickSale:"⚡ Quick Sale",newSale:"+ New Sale",addProd:"+ Product",addExp:"+ Expense",addCat:"+ Category",
    totalRev:"Total Revenue",todaySales:"Today's Sales",unpaidBal:"Unpaid Balance",netProfit:"Net Profit",
    paid:"Paid",unpaid:"Unpaid",all:"All",save:"Save",cancel:"Cancel",
    cust:"Customer",date:"Date",total:"Total",method:"Method",status:"Status",
    prod:"Product",cat:"Category",price:"Price",cost:"Cost",stock:"Stock",
    reorderAt:"Min",orderQty:"Order Qty",note:"Note",amt:"Amount",unit:"Unit",
    inc:"Income",exp2:"Expense",profit:"Profit",search:"🔍 Search...",
    markPaid:"Mark Paid ✓",payHist:"Payment History",recSales:"Recent Sales",
    allSettled:"All settled! 🎉",allStocked:"All stocked ✅",
    daily:"Daily",weekly:"Weekly",monthly:"Monthly",
    today:"Today",thisWeek:"This Week",thisMonth:"This Month",
    topProds:"Top Products",expBrk:"Expense Breakdown",
    logout:"Logout",lang:"Filipino",
    bkNow:"Backup Now",createBk:"Create Backup",restoreFile:"Restore from File",
    autoBk:"Auto Backups",manBk:"Manual Backups",
    adj:"Adjust",reorderList:"Reorder List",shortage:"Shortage",estCost:"Est. Cost",
    pri:"Priority",critical:"Critical",high:"High",medium:"Medium",
    duplicate:"Duplicate",edit:"Edit",delete:"Delete",
    catName:"Category Name",catColor:"Color",sku:"SKU",
  }
};

// ═══════════════════════════════════════════════ UI ATOMS
// ── Back Button Component ──────────────────────────
function BackBtn({setTab,label}) {
  return (
    <button onClick={()=>setTab("dashboard")}
      style={{display:"inline-flex",alignItems:"center",gap:6,padding:"7px 14px",borderRadius:8,
        background:C.bg3,border:"1px solid "+C.b2,color:C.d2,fontSize:13,fontWeight:600,cursor:"pointer",marginBottom:4}}>
      ← {label||"Dashboard"}
    </button>
  );
}

// ── Clickable StatCard ──────────────────────────────
function ClickStatCard({v,label,sub,color,icon,onClick}) {
  return (
    <div onClick={onClick} style={{background:C.bg2,border:"1px solid "+C.b,borderTop:"3px solid "+color,
      borderRadius:10,padding:"12px 14px",cursor:onClick?"pointer":"default",transition:"all 0.12s"}}>
      <div style={{fontSize:10,color:C.d2,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.4px",marginBottom:4}}>{icon} {label}</div>
      <div style={{fontSize:21,fontWeight:800,color:"#fff"}}>{v}</div>
      {sub&&<div style={{fontSize:11,color:C.d2,marginTop:3}}>{sub}</div>}
      {onClick&&<div style={{fontSize:10,color:color,marginTop:4,fontWeight:600}}>Tap para detalye →</div>}
    </div>
  );
}

// ── Toast Notification System ─────────────────────
const ToastCtx = React.createContext(null);
function ToastProvider({children}) {
  const [toasts,setToasts] = React.useState([]);
  const show = React.useCallback((msg,type="success",dur=2800)=>{
    const id=Date.now();
    setToasts(prev=>[...prev,{id,msg,type}]);
    setTimeout(()=>setToasts(prev=>prev.filter(x=>x.id!==id)),dur);
  },[]);
  const clr={success:[C.gr,C.gd],error:[C.re,C.rd],info:[C.bl,C.bd],warning:[C.am,C.ad]};
  return (
    <ToastCtx.Provider value={show}>
      {children}
      <div style={{position:"fixed",bottom:28,left:"50%",transform:"translateX(-50%)",
        zIndex:9999,display:"flex",flexDirection:"column",gap:8,alignItems:"center",
        pointerEvents:"none",width:"90%",maxWidth:360}}>
        {toasts.map(item=>{
          const [fg,bg]=clr[item.type]||clr.success;
          return (
            <div key={item.id} style={{background:bg,border:"2px solid "+fg,borderRadius:12,
              padding:"11px 18px",color:fg,fontWeight:700,fontSize:13,textAlign:"center",
              boxShadow:"0 4px 20px rgba(0,0,0,0.5)",animation:"slideUp 0.25s ease",
              width:"100%"}}>
              {item.type==="success"?"✅":item.type==="error"?"❌":item.type==="warning"?"⚠️":"ℹ️"} {item.msg}
            </div>
          );
        })}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = ()=>React.useContext(ToastCtx);

const col_m = {green:[C.gr,C.gd],red:[C.re,C.rd],amber:[C.am,C.ad],blue:[C.bl,C.bd],purple:[C.pu,C.pd]};

function Chip({c,children}) {
  const [fg,bg] = col_m[c]||[C.d2,C.bg3];
  return <span style={{display:"inline-flex",alignItems:"center",padding:"2px 8px",borderRadius:20,fontSize:11,fontWeight:700,color:fg,background:bg,whiteSpace:"nowrap"}}>{children}</span>;
}
function Card({title,right,children}) {
  return (
    <div style={{background:C.bg2,border:`1px solid ${C.b}`,borderRadius:10,overflow:"hidden"}}>
      {title && <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.b}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <span style={{fontSize:13,fontWeight:700,color:"#fff"}}>{title}</span>{right}
      </div>}
      {children}
    </div>
  );
}
function StatCard({v,label,sub,color,icon}) {
  return (
    <div style={{background:C.bg2,border:`1px solid ${C.b}`,borderTop:`3px solid ${color}`,borderRadius:10,padding:"12px 14px"}}>
      <div style={{fontSize:10,color:C.d2,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.4px",marginBottom:4}}>{icon} {label}</div>
      <div style={{fontSize:21,fontWeight:800,color:"#fff"}}>{v}</div>
      {sub && <div style={{fontSize:11,color:C.d2,marginTop:3}}>{sub}</div>}
    </div>
  );
}
function AlertBar({c,children}) {
  const [fg,bg] = col_m[c]||[C.d2,C.bg3];
  return <div style={{background:bg,border:`1px solid ${fg}33`,borderRadius:8,padding:"9px 12px",color:fg,fontSize:12,fontWeight:600}}>{children}</div>;
}
function Tbl({cols,rows}) {
  return (
    <div style={{overflowX:"auto"}}>
      <table style={{width:"100%",borderCollapse:"collapse",minWidth:cols.length*70}}>
        <thead><tr>{cols.map((c,i) => <th key={i} style={{padding:"8px 12px",textAlign:"left",fontSize:10,fontWeight:700,color:C.d2,textTransform:"uppercase",letterSpacing:"0.4px",background:C.bg3,borderBottom:`1px solid ${C.b}`,whiteSpace:"nowrap"}}>{c}</th>)}</tr></thead>
        <tbody>{rows.map((r,i) => <tr key={i}>{r.map((c,j) => <td key={j} style={{padding:"9px 12px",fontSize:13,color:C.tx,borderBottom:`1px solid ${C.b}`,verticalAlign:"middle"}}>{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}
function B({children}) { return <span style={{fontWeight:700,color:"#fff"}}>{children}</span>; }
function Dim({children}) { return <span style={{color:C.d2,fontSize:12}}>{children}</span>; }
function Empty({children}) { return <div style={{padding:"32px",textAlign:"center",color:C.d2,fontSize:13}}>{children}</div>; }
function Grid2({children}) { return <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10}}>{children}</div>; }
const colStyle = {display:"flex",flexDirection:"column",gap:12};
const lbSt = {display:"block",fontSize:11,fontWeight:700,color:C.d2,marginBottom:5,textTransform:"uppercase",letterSpacing:"0.3px"};
function iSt() { return {background:C.bg3,border:`1px solid ${C.b2}`,borderRadius:7,padding:"9px 12px",fontSize:13,color:C.tx,outline:"none",width:"100%",fontFamily:"inherit"}; }
function bSt(bg,fg) { return {display:"inline-flex",alignItems:"center",gap:5,padding:"8px 14px",borderRadius:7,fontSize:13,fontWeight:600,cursor:"pointer",border:"none",background:bg||C.ac,color:fg||"#fff",whiteSpace:"nowrap",fontFamily:"inherit"}; }
function gBtn() { return {display:"inline-flex",alignItems:"center",gap:5,padding:"7px 12px",borderRadius:7,fontSize:12,fontWeight:600,cursor:"pointer",border:`1px solid ${C.b2}`,background:"transparent",color:C.d2,whiteSpace:"nowrap",fontFamily:"inherit"}; }

// ═══════════════════════════════════════════════ MODAL BASE
function MBase({title,onClose,children}) {
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.82)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:100}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:C.bg2,border:`1px solid ${C.b2}`,borderRadius:"14px 14px 0 0",padding:"18px 16px 36px",width:"100%",maxWidth:540,maxHeight:"92vh",overflowY:"auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <span style={{fontSize:15,fontWeight:800,color:"#fff"}}>{title}</span>
          <button onClick={onClose} style={{background:"none",border:"none",color:C.d2,fontSize:24,cursor:"pointer",lineHeight:1}}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════ LOGIN
function LoginScreen({t,lang,setLang,onLogin}) {
  const [sel,setSel] = useState(null);
  const [pin,setPin] = useState("");
  const [err,setErr] = useState("");
  const go = () => {
    const u = USERS.find(u=>u.id===sel&&u.pin===pin);
    if(u) onLogin(u); else { setErr(t.wrongPin); setPin(""); }
  };
  return (
    <div style={{minHeight:"100vh",background:C.bg0,display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
      <div style={{width:"100%",maxWidth:380,background:C.bg2,border:`1px solid ${C.b}`,borderRadius:18,padding:"28px 20px",boxShadow:"0 32px 80px rgba(0,0,0,0.7)"}}>
        <div style={{textAlign:"center",marginBottom:24}}>
          <div style={{fontSize:52,marginBottom:6}}>🏪</div>
          <div style={{fontSize:24,fontWeight:800,color:"#fff",letterSpacing:"-0.5px"}}>{t.app}</div>
          <div style={{fontSize:11,color:C.d2,marginTop:3}}>{t.sub} · v4.0</div>
        </div>
        <div style={{fontSize:11,fontWeight:700,color:C.d2,textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10}}>{t.selAcc}</div>
        <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:18}}>
          {USERS.map(u => (
            <button key={u.id} onClick={()=>{setSel(u.id);setPin("");setErr("");}}
              style={{display:"flex",alignItems:"center",gap:12,padding:"12px 14px",borderRadius:10,border:`1px solid ${sel===u.id?u.color:C.b2}`,background:sel===u.id?`${u.color}15`:C.bg3,cursor:"pointer",textAlign:"left",transition:"all 0.15s"}}>
              <span style={{fontSize:22}}>{u.emoji}</span>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:"#fff"}}>{u.name}</div>
                <div style={{fontSize:10,color:u.color,fontWeight:700,textTransform:"uppercase"}}>{u.role}</div>
              </div>
              {sel===u.id && <span style={{marginLeft:"auto",color:u.color,fontSize:18}}>●</span>}
            </button>
          ))}
        </div>
        {sel && (
          <div>
            <div style={{fontSize:11,fontWeight:700,color:C.d2,textTransform:"uppercase",marginBottom:6}}>{t.pin}</div>
            <input type="password" maxLength={6} autoFocus value={pin} placeholder="••••"
              style={{...iSt(),fontSize:22,letterSpacing:10,textAlign:"center",marginBottom:8}}
              onChange={e=>setPin(e.target.value)} onKeyDown={e=>e.key==="Enter"&&go()}/>
            {err && <div style={{background:C.rd,border:`1px solid ${C.re}`,borderRadius:7,padding:"7px 12px",color:C.re,fontSize:12,fontWeight:600,marginBottom:8}}>{err}</div>}
            <button onClick={go} style={{...bSt(),width:"100%",justifyContent:"center",padding:"12px",fontSize:14}}>🔐 {t.login}</button>
          </div>
        )}
        <div style={{textAlign:"center",marginTop:12,fontSize:10,color:C.d3}}>{t.demo}</div>
        <div style={{marginTop:10,background:C.bg3,borderRadius:8,padding:"9px 12px",textAlign:"center"}}>
          <div style={{fontSize:10,color:C.d2,lineHeight:1.6}}>
            🔒 <strong style={{color:C.gr}}>Offline-first</strong> — Naka-save sa inyong phone. Walang internet na kailangan.
          </div>
        </div>
        <button onClick={()=>setLang(l=>l==="tl"?"en":"tl")} style={{width:"100%",background:"none",border:"none",color:C.d2,cursor:"pointer",fontSize:12,fontWeight:600,marginTop:10}}>🌐 {t.lang}</button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════ SIDEBAR BUTTON
// ── Onboarding Modal ──────────────────────────────
function OnboardingModal({onDone,setTab}) {
  const [step,setStep]=React.useState(0);
  const steps=[
    {icon:"🏪",col:C.gr,title:"Maligayang pagdating sa Bantay Benta!",
      desc:"Ang pinakamagandang paraan para ma-track ang inyong tindahan. Tour muna tayo!",
      tips:null,action:null,btn:"Magsimula →",bc:C.gr,bfg:"#000"},
    {icon:"📦",col:C.bl,title:"Una: I-add ang iyong mga Produkto",
      desc:"Pumunta sa Imbentaryo at i-tap ang + Produkto.",
      tips:["Lagyan ng Pangalan, Presyo, at Stock","Lagyan ng Cost/Puhunan para ma-compute ang profit","Para sa tingi (per stick/piece): lagyan ng setup sa Tingi section","Para sa Marlboro Red/Blue/Menthol: lagyan ng Variants"],
      action:"inventory",btn:"Susunod →",bc:C.bl,bfg:"#fff"},
    {icon:"⚡",col:C.gr,title:"I-record ang Benta gamit Quick Sale",
      desc:"3 taps lang — pinaka-mabilis na paraan.",
      tips:["TAP 1: Hanapin at i-tap ang produkto","TAP 2: Piliin kung BUO (buong pack) o TINGI (per piece), tapos ang dami","TAP 3: I-tap ang IBENTA — naitala na!","Pwede mag-add ng maraming produkto bago mag-IBENTA"],
      action:"quicksale",btn:"Susunod →",bc:C.gr,bfg:"#000"},
    {icon:"📋",col:C.am,title:"I-track ang mga Utang",
      desc:"Kapag nag-utang ang customer — ganito ang paraan.",
      tips:["Sa Quick Sale, palitan ang Cash → Utang","Makikita sa 📋 Payments tab","Tap ang pangalan para makita ang binili","Pwede mag-partial payment","I-tap ang Bayad na ✓ kapag naka-bayad na"],
      action:"payments",btn:"Susunod →",bc:C.am,bfg:"#000"},
    {icon:"📊",col:C.pu,title:"Dashboard at Reports",
      desc:"Tingnan ang performance ng inyong tindahan.",
      tips:["Tap ang kahit anong stat card sa Dashboard para makita ang detalye","Reports tab: Daily/Weekly/Monthly o custom dates","Reorder list: kapag mababa na ang stock","Backup: i-save ang inyong data regularly"],
      action:"dashboard",btn:"Simulan Na! 🚀",bc:C.gr,bfg:"#000"},
  ];
  const s=steps[step];
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.96)",display:"flex",
      alignItems:"flex-end",justifyContent:"center",zIndex:9500}}>
      <div style={{background:C.bg1,borderTop:"3px solid "+s.col,borderRadius:"18px 18px 0 0",
        padding:"20px 18px 38px",width:"100%",maxWidth:480,maxHeight:"88vh",overflowY:"auto"}}>
        {/* Progress */}
        <div style={{display:"flex",gap:4,marginBottom:16}}>
          {steps.map((_,i)=><div key={i} style={{flex:1,height:4,borderRadius:2,
            background:i<=step?s.col:C.b2,transition:"background 0.3s"}}/>)}
        </div>
        <div style={{fontSize:11,color:C.d2,fontWeight:700,marginBottom:10,textTransform:"uppercase"}}>
          Hakbang {step+1} sa {steps.length}
        </div>
        <div style={{background:s.col+"15",border:"1px solid "+s.col+"40",borderRadius:12,
          padding:"16px",textAlign:"center",marginBottom:14}}>
          <div style={{fontSize:42,marginBottom:8}}>{s.icon}</div>
          <div style={{fontSize:16,fontWeight:800,color:s.col,marginBottom:6,lineHeight:1.3}}>{s.title}</div>
          <div style={{fontSize:13,color:C.d2,lineHeight:1.6}}>{s.desc}</div>
        </div>
        {s.tips&&(
          <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:14}}>
            {s.tips.map((tip,i)=>(
              <div key={i} style={{display:"flex",gap:10,background:C.bg2,border:"1px solid "+C.b,
                borderRadius:9,padding:"9px 12px",alignItems:"flex-start"}}>
                <span style={{background:s.col+"25",color:s.col,borderRadius:5,padding:"2px 7px",
                  fontSize:11,fontWeight:800,flexShrink:0}}>{i+1}</span>
                <span style={{fontSize:13,color:"#fff",lineHeight:1.5}}>{tip}</span>
              </div>
            ))}
          </div>
        )}
        {s.action&&(
          <button onClick={()=>setTab(s.action)}
            style={{...gBtn(),width:"100%",justifyContent:"center",marginBottom:8,
              color:s.col,border:"1px solid "+s.col,padding:"9px"}}>
            Pumunta doon →
          </button>
        )}
        <button onClick={()=>{if(step<steps.length-1)setStep(step+1);else{localStorage.setItem("bb4_onboarded","1");onDone();if(s.action)setTab(s.action);}}}
          style={{...bSt(s.bc,s.bfg),width:"100%",justifyContent:"center",padding:"13px",
            fontSize:15,fontWeight:800,borderRadius:11,marginBottom:7}}>
          {s.btn}
        </button>
        {step>0&&<button onClick={()=>setStep(step-1)}
          style={{...gBtn(),width:"100%",justifyContent:"center",marginBottom:6}}>← Bumalik</button>}
        <button onClick={()=>{localStorage.setItem("bb4_onboarded","1");onDone();}}
          style={{width:"100%",background:"none",border:"none",color:C.d3,cursor:"pointer",fontSize:12,padding:"5px"}}>
          Laktawan ang tutorial
        </button>
      </div>
    </div>
  );
}

function SBtn({n,active,onClick}) {
  return (
    <button onClick={onClick} style={{width:"100%",display:"flex",alignItems:"center",gap:9,padding:"10px 12px",
      background:active?(n.highlight?"rgba(34,211,160,0.15)":"rgba(77,158,255,0.1)"):"transparent",
      borderLeft:`2px solid ${active?(n.highlight?C.gr:C.bl):"transparent"}`,
      color:active?"#fff":C.d2,fontWeight:active?700:400,fontSize:13,cursor:"pointer",
      border:"none",borderLeft:`2px solid ${active?(n.highlight?C.gr:C.bl):"transparent"}`,
      textAlign:"left",transition:"all 0.12s"}}>
      <span style={{fontSize:15}}>{n.icon}</span>
      <span style={{flex:1,color:n.highlight&&!active?C.gr:"inherit"}}>{n.label}</span>
      {n.pulse&&!active&&<span style={{background:C.bl,color:"#fff",borderRadius:8,fontSize:9,fontWeight:800,padding:"2px 6px",animation:"pulse 1.5s ease infinite"}}>START</span>}
      {!n.pulse&&n.badge>0&&<span style={{background:C.re,color:"#fff",borderRadius:20,fontSize:10,fontWeight:700,padding:"1px 6px"}}>{n.badge}</span>}
    </button>
  );
}

  

// ═══════════════════════════════════════════════ MODALS
// ── Editable Customer Input with saved names ──────
function CustomerInput({value, onChange}) {
  const [saved, setSaved] = React.useState(()=>DB.get("cust_names",[]));
  const [show,  setShow]  = React.useState(false);
  const filtered = saved.filter(n=>n.toLowerCase().includes(value.toLowerCase())&&n!==value);
  const saveNew=()=>{
    if(!value.trim()||saved.includes(value.trim())) return;
    const updated=[value.trim(),...saved].slice(0,30);
    setSaved(updated);
    DB.set("cust_names",updated);
  };
  const remove=(name)=>{
    const updated=saved.filter(n=>n!==name);
    setSaved(updated);
    DB.set("cust_names",updated);
  };
  return (
    <div style={{position:"relative"}}>
      <div style={{display:"flex",gap:6}}>
        <input style={{...iSt(),flex:1}} placeholder="Pangalan ng customer (optional)"
          value={value}
          onChange={e=>{onChange(e.target.value);setShow(true);}}
          onFocus={()=>setShow(true)}
          onBlur={()=>setTimeout(()=>setShow(false),200)}/>
        {value.trim()&&!saved.includes(value.trim())&&(
          <button onMouseDown={saveNew}
            style={{...gBtn(),fontSize:11,flexShrink:0,color:C.gr,border:"1px solid "+C.gr}}>
            💾 Save
          </button>
        )}
      </div>
      {show&&(saved.length>0||filtered.length>0)&&(
        <div style={{position:"absolute",top:"100%",left:0,right:0,background:C.bg2,
          border:"1px solid "+C.b2,borderRadius:8,zIndex:100,maxHeight:160,overflowY:"auto",marginTop:2}}>
          {(value.trim()?filtered:saved).map(name=>(
            <div key={name} style={{display:"flex",alignItems:"center",padding:"8px 12px",
              borderBottom:"1px solid "+C.b,cursor:"pointer"}}
              onMouseDown={()=>{onChange(name);setShow(false);}}>
              <span style={{flex:1,fontSize:13,color:"#fff"}}>{name}</span>
              <button onMouseDown={e=>{e.stopPropagation();remove(name);}}
                style={{background:"none",border:"none",color:C.d3,cursor:"pointer",fontSize:14}}>×</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SaleModal({t,products,addSale,onClose}) {
  const [cust,setCust]=useState("");
  const [date,setDate]=useState(td());
  const [method,setMethod]=useState("Cash");
  const [isPaid,setIsPaid]=useState(true);
  const [items,setItems]=useState([{pid:(products[0]&&products[0].id),qty:1}]);
  const total=items.reduce((a,it)=>{const p=products.find(x=>x.id===Number(it.pid)||x.id===it.pid);return a+(p?p.price*it.qty:0);},0);
  const upd=(i,k,v)=>setItems(p=>p.map((it,x)=>x===i?{...it,[k]:k==="qty"?Math.max(1,Number(v)):v}:it));
  const save=()=>{
    if(!cust.trim()){alert("Lagyan ng pangalan.");return;}
    const si=items.map(it=>{const p=products.find(x=>x.id===Number(it.pid)||x.id===it.pid);return{pid:p.id,name:p.name,qty:Number(it.qty),price:p.price,unit:p.unit||"piraso"};});
    addSale({cust,date,items:si,total,paid:isPaid,method});onClose();
  };
  return (
    <MBase title={"💰 "+t.newSale} onClose={onClose}>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        <div><label style={lbSt}>{t.cust}</label><CustomerInput value={cust} onChange={setCust}/></div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div><label style={lbSt}>{t.date}</label><input type="date" style={iSt()} value={date} onChange={e=>setDate(e.target.value)}/></div>
          <div><label style={lbSt}>{t.method}</label><select style={iSt()} value={method} onChange={e=>setMethod(e.target.value)}>{["Cash","GCash","PayMaya","Utang"].map(m=><option key={m}>{m}</option>)}</select></div>
        </div>
        <div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
            <label style={lbSt}>{t.prod}</label>
            <button style={{...gBtn(),fontSize:11}} onClick={()=>setItems(p=>[...p,{pid:(products[0]&&products[0].id),qty:1}])}>+ Dagdag</button>
          </div>
          {items.map((it,i)=>{
            const p=products.find(x=>x.id===Number(it.pid)||x.id===it.pid);
            return (
              <div key={i} style={{display:"flex",gap:6,marginBottom:6,alignItems:"center"}}>
                <select style={{...iSt(),flex:2}} value={it.pid} onChange={e=>upd(i,"pid",e.target.value)}>
                  {products.map(p=><option key={p.id} value={p.id}>{p.name} {P(p.price)}</option>)}
                </select>
                <div style={{display:"flex",alignItems:"center",gap:3,flex:"none"}}>
                  <button style={{background:C.bg3,border:"1px solid "+C.b2,borderRadius:5,width:26,height:34,color:"#fff",cursor:"pointer",fontSize:16,flexShrink:0}} onClick={()=>upd(i,"qty",Math.max(1,it.qty-1))}>−</button>
                  <input type="number" min="1" style={{...iSt(),width:46,textAlign:"center",padding:"4px",fontSize:14}} value={it.qty} onChange={e=>upd(i,"qty",e.target.value)}/>
                  <button style={{background:C.bl,border:"none",borderRadius:5,width:26,height:34,color:"#fff",cursor:"pointer",fontSize:16,flexShrink:0}} onClick={()=>upd(i,"qty",it.qty+1)}>+</button>
                </div>
                <span style={{color:C.gr,fontWeight:700,minWidth:52,textAlign:"right",fontSize:12}}>{p?P(p.price*it.qty):"—"}</span>
                {items.length>1 && <button style={{...gBtn(),color:C.re,padding:"4px 8px"}} onClick={()=>setItems(p=>p.filter((_,x)=>x!==i))}>✕</button>}
              </div>
            );
          })}
        </div>
        <div><label style={lbSt}>Status</label><select style={iSt()} value={isPaid?"paid":"utang"} onChange={e=>setIsPaid(e.target.value==="paid")}><option value="paid">{t.paid} ✓</option><option value="utang">{t.unpaid}</option></select></div>
        <div style={{background:C.bg3,borderRadius:8,padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span style={{color:C.d2,fontWeight:600}}>{t.total}</span>
          <span style={{color:C.gr,fontSize:22,fontWeight:800}}>{P(total)}</span>
        </div>
        <div style={{display:"flex",gap:8}}>
          <button style={{...gBtn(),flex:1}} onClick={onClose}>{t.cancel}</button>
          <button style={{...bSt(),flex:2}} onClick={save}>{t.save}</button>
        </div>
      </div>
    </MBase>
  );
}

function ProdModal({t,cats,addProduct,editProduct,addExpense,onClose,mode,existing}) {
  const genSKU = (name) => {
    const words = name.trim().toUpperCase().split(/\s+/);
    const prefix = words.map(w=>w[0]||"").join("").slice(0,3).padEnd(2,"X");
    return prefix+"-"+Math.random().toString(36).slice(2,5).toUpperCase();
  };
  const blank={name:"",sku:"",cat:(cats[0]&&cats[0].name)||"Pagkain",price:"",cost:"",stock:"",min:10,orderQty:30,unit:"piraso",unitsPerPack:"",pricePerUnit:"",variants:[]};
  const [f,setF]=useState(mode==="edit"?{...existing,unitsPerPack:existing.unitsPerPack||"",pricePerUnit:existing.pricePerUnit||"",variants:existing.variants||[]}:blank);
  const sv=(k,v)=>setF(p=>({...p,[k]:v}));

  // Auto-generate SKU when name changes
  const handleNameChange=(val)=>{
    sv("name",val);
    if(mode==="add"&&(!f.sku||f.sku===genSKU(f.name.slice(0,-1)))) {
      if(val.trim().length>=2) sv("sku",genSKU(val));
    }
  };

  // Compute
  const unitsPerPack = +f.unitsPerPack||0;
  const pricePerUnit = +f.pricePerUnit||0;
  const cost         = +f.cost||0;
  const hasBreakdown = unitsPerPack>0 && pricePerUnit>0;
  const buoPrice     = hasBreakdown ? unitsPerPack * pricePerUnit : 0;
  const tuboPerPack  = hasBreakdown ? buoPrice - cost : 0;
  const tuboPerUnit  = hasBreakdown && unitsPerPack>0 ? tuboPerPack/unitsPerPack : 0;
  const marginPct    = buoPrice>0 ? ((tuboPerPack/buoPrice)*100).toFixed(1) : 0;

  const save=()=>{
    if(!f.name.trim()){alert("Lagyan ng pangalan ng produkto.");return;}
    if(!f.price||+f.price<=0){alert("Lagyan ng selling price.");return;}
    const sku = f.sku.trim()||genSKU(f.name);
    const data={...f,sku,price:+f.price,cost:+f.cost,stock:+f.stock,min:+f.min,orderQty:+f.orderQty,
      unitsPerPack:+f.unitsPerPack||0,pricePerUnit:+f.pricePerUnit||0,variants:f.variants||[]};
    if(mode==="edit") {
      editProduct(data);
    } else {
      addProduct(data);
      // Record as Stock Purchase (separate from operating expenses)
      if(+f.cost>0 && +f.stock>0) {
        DB.addStockPurchase({
          date: new Date().toISOString().slice(0,10),
          product: f.name,
          qty: +f.stock,
          costPerUnit: +f.cost,
          totalCost: +f.cost * +f.stock,
          note: "Initial stock — "+f.stock+" "+( f.unit||"pcs")+" @ "+P(+f.cost)+" each"
        });
      }
    }
    onClose();
  };

  return (
    <MBase title={mode==="edit"?"✏️ I-edit ang Produkto":"📦 "+t.addProd} onClose={onClose}>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>

        {/* Basic info */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div style={{gridColumn:"1/-1"}}>
            <label style={lbSt}>Pangalan *</label>
            <input style={iSt()} value={f.name} onChange={e=>handleNameChange(e.target.value)} placeholder="e.g. Marlboro, Bigas 5kg"/>
          </div>
          <div>
            <label style={lbSt}>SKU (Auto)</label>
            <input style={{...iSt(),color:C.d2}} value={f.sku} onChange={e=>sv("sku",e.target.value)} placeholder="Auto-generate..."/>
          </div>
          <div>
            <label style={lbSt}>{t.cat}</label>
            <select style={iSt()} value={f.cat} onChange={e=>sv("cat",e.target.value)}>
              {cats.map(c=><option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label style={lbSt}>Unit (per piece)</label>
            <select style={iSt()} value={f.unit||"piraso"} onChange={e=>sv("unit",e.target.value)}>
              {TINGI_UNITS.map(u=><option key={u.val} value={u.val}>{u.label}</option>)}
            </select>
          </div>
          <div>
            <label style={lbSt}>Cost of Capital (₱ per pack/unit)</label>
            <input type="number" style={iSt()} value={f.cost} onChange={e=>sv("cost",e.target.value)} placeholder="e.g. 250"/>
            <div style={{fontSize:10,color:C.d2,marginTop:3}}>Presyo ng binili mo (wholesale/puhunan)</div>
          </div>
          <div>
            <label style={lbSt}>Stock (bilang ng pack/unit)</label>
            <input type="number" style={iSt()} value={f.stock} onChange={e=>sv("stock",e.target.value)}/>
          </div>
        </div>

        {/* Cost of Capital note */}
        {+f.cost>0&&+f.stock>0&&mode==="add"&&(
          <div style={{background:C.ad,border:"1px solid "+C.am,borderRadius:8,padding:"9px 12px",fontSize:12}}>
            <span style={{color:C.am,fontWeight:700}}>💡 Auto-gastos: </span>
            <span style={{color:"#fff"}}>{P(+f.cost)} × {f.stock} = </span>
            <span style={{color:C.am,fontWeight:800}}>{P(+f.cost * +f.stock)}</span>
            <span style={{color:C.d2}}> — ilalagay sa Gastos (Puhunan)</span>
          </div>
        )}



        {/* Tingi Setup */}
        <div style={{background:C.bg3,border:"1px solid "+C.bl,borderRadius:10,padding:"12px 14px"}}>
          <div style={{fontSize:12,fontWeight:800,color:C.bl,marginBottom:10}}>📦 Tingi Setup (Optional) — Para sa per-piece selling</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
            <div>
              <label style={lbSt}>Pieces in a Pack</label>
              <input type="number" style={iSt()} value={f.unitsPerPack}
                onChange={e=>sv("unitsPerPack",e.target.value)} placeholder="e.g. 20 sticks"/>
              <div style={{fontSize:10,color:C.d2,marginTop:3}}>Ilan ang piraso sa isang pack?</div>
            </div>
            <div>
              <label style={lbSt}>Tingi Price (₱ per {f.unit||"piraso"})</label>
              <input type="number" style={iSt()} value={f.pricePerUnit}
                onChange={e=>sv("pricePerUnit",e.target.value)} placeholder="e.g. ₱15 per stick"/>
              <div style={{fontSize:10,color:C.d2,marginTop:3}}>Presyo bawat piraso</div>
            </div>
          </div>



          {/* Auto-compute result */}
          {hasBreakdown&&(
            <div style={{background:C.bg2,borderRadius:8,padding:"12px",display:"flex",flexDirection:"column",gap:5}}>
              <div style={{fontSize:11,fontWeight:700,color:C.d2,textTransform:"uppercase",marginBottom:4}}>📊 Auto-Compute:</div>
              {[
                ["Pieces in pack", unitsPerPack+" pcs", "#fff"],
                ["Use Tingi @ "+P(pricePerUnit), unitsPerPack+"×"+P(pricePerUnit)+" = "+P(buoPrice), C.gr],
                ["Cost of Capital", "−"+P(cost), C.re],
                ["Gross Profit per pack", P(tuboPerPack), tuboPerPack>=0?C.gr:C.re],
                ["Profit per piece", P(tuboPerUnit), tuboPerPack>=0?C.gr:C.re],
                ["Margin", marginPct+"%", tuboPerPack>=0?C.am:C.re],
              ].map(([lbl,val,col],i)=>(
                <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:i<5?"1px solid "+C.b:"none"}}>
                  <span style={{fontSize:12,color:C.d2}}>{lbl}</span>
                  <span style={{fontSize:12,fontWeight:700,color:col}}>{val}</span>
                </div>
              ))}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:6}}>
                <button onClick={()=>sv("price",buoPrice.toString())}
                  style={{...bSt(C.bl,"#fff"),justifyContent:"center",fontSize:11,padding:"7px"}}>
                  📦 Pack Price {P(buoPrice)}
                </button>
                <button onClick={()=>sv("price",pricePerUnit.toString())}
                  style={{...bSt(C.am,"#000"),justifyContent:"center",fontSize:11,padding:"7px"}}>
                  ✂️ Use Tingi {P(pricePerUnit)}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Selling price */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div>
            <label style={lbSt}>Selling Price (₱) *</label>
            <input type="number" style={{...iSt(),border:"1px solid "+C.gr}} value={f.price}
              onChange={e=>sv("price",e.target.value)} placeholder="Presyo sa customer"/>
          </div>
          <div>
            <label style={lbSt}>Min Stock</label>
            <input type="number" style={iSt()} value={f.min} onChange={e=>sv("min",e.target.value)}/>
          </div>
          <div style={{gridColumn:"1/-1"}}>
            <label style={lbSt}>Order Qty</label>
            <input type="number" style={iSt()} value={f.orderQty} onChange={e=>sv("orderQty",e.target.value)}/>
          </div>
        </div>

        <div style={{display:"flex",gap:8}}>
          <button style={{...gBtn(),flex:1}} onClick={onClose}>{t.cancel}</button>
          <button style={{...bSt(),flex:2}} onClick={save}>{t.save}</button>
        </div>
      </div>
    </MBase>
  );
}
function CatModal({t,addCat,editCat,onClose,mode,existing}) {
  const [name,setName]=useState(mode==="edit"?existing.name:"");
  const [color,setColor]=useState(mode==="edit"?existing.color:CAT_COLORS[0]);
  const save=()=>{
    if(!name.trim()){alert("Lagyan ng pangalan.");return;}
    if(mode==="edit") editCat({...existing,name,color}); else addCat({name,color});
    onClose();
  };
  return (
    <MBase title={mode==="edit"?"✏️ I-edit ang Kategorya":"🏷️ Bagong Kategorya"} onClose={onClose}>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        <div><label style={lbSt}>{t.catName} *</label><input style={iSt()} value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Pagkain"/></div>
        <div>
          <label style={lbSt}>{t.catColor}</label>
          <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:4}}>
            {CAT_COLORS.map(c => (
              <button key={c} onClick={()=>setColor(c)}
                style={{width:34,height:34,borderRadius:"50%",background:c,border:color===c?"3px solid #fff":"2px solid transparent",cursor:"pointer"}}/>
            ))}
          </div>
        </div>
        <div style={{background:C.bg3,borderRadius:8,padding:"10px 14px",display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:16,height:16,borderRadius:"50%",background:color}}/>
          <span style={{fontSize:13,fontWeight:700,color:"#fff"}}>{name||"Preview"}</span>
        </div>
        <div style={{display:"flex",gap:8}}>
          <button style={{...gBtn(),flex:1}} onClick={onClose}>{t.cancel}</button>
          <button style={{...bSt(),flex:2}} onClick={save}>{t.save}</button>
        </div>
      </div>
    </MBase>
  );
}

function ExpModal({t,addExpense,onClose}) {
  const types=["Upa/Rent","Kuryente","Tubig","Sahod","Ice","Load","Transportasyon","Iba pa"];
  const [f,setF]=useState({date:td(),type:types[0],amount:"",note:""});
  const s=(k,v)=>setF(p=>({...p,[k]:v}));
  const save=()=>{if(!f.amount||+f.amount<=0){alert("Lagyan ng halaga.");return;}addExpense({...f,amount:+f.amount});onClose();};
  return (
    <MBase title={"🧾 "+t.addExp} onClose={onClose}>
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        <div><label style={lbSt}>{t.date}</label><input type="date" style={iSt()} value={f.date} onChange={e=>s("date",e.target.value)}/></div>
        <div><label style={lbSt}>Uri</label><select style={iSt()} value={f.type} onChange={e=>s("type",e.target.value)}>{types.map(tp=><option key={tp}>{tp}</option>)}</select></div>
        <div><label style={lbSt}>{t.amt} (₱)</label><input type="number" style={iSt()} value={f.amount} onChange={e=>s("amount",e.target.value)} placeholder="0.00"/></div>
        <div><label style={lbSt}>{t.note}</label><input style={iSt()} value={f.note} onChange={e=>s("note",e.target.value)} placeholder="Opsyonal..."/></div>
        <div style={{display:"flex",gap:8}}>
          <button style={{...gBtn(),flex:1}} onClick={onClose}>{t.cancel}</button>
          <button style={{...bSt(),flex:2}} onClick={save}>{t.save}</button>
        </div>
      </div>
    </MBase>
  );
}

  

// ═══════════════════════════════════════════════ PAGES (condensed)
function CashFlowPanel({totalRev,totalExp}) {
  const sp  = DB.getStockPurchases();
  const cin = totalRev;
  const cout_stock = sp.reduce((a,s)=>a+(+s.totalCost||0),0);
  const cout = cout_stock + totalExp;
  const bal  = cin - cout;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:10}}>
      <div style={{background:"linear-gradient(135deg,#071428,#0a1628)",border:"1px solid "+C.bl,borderRadius:12,padding:"14px 16px"}}>
        <div style={{fontSize:11,fontWeight:700,color:C.d2,marginBottom:10,textTransform:"uppercase"}}>💵 Cash Flow</div>
        {[["💰 Cash In (Sales)",P(cin),C.am],["📦 Stock Purchases","−"+P(cout_stock),C.re],["🧾 Expenses","−"+P(totalExp),C.re]].map(([l,v,c],i)=>(
          <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid "+C.b}}>
            <span style={{fontSize:13,color:C.d2}}>{l}</span>
            <span style={{fontSize:14,fontWeight:700,color:c}}>{v}</span>
          </div>
        ))}
        <div style={{display:"flex",justifyContent:"space-between",paddingTop:8}}>
          <span style={{fontSize:14,fontWeight:800,color:"#fff"}}>💵 Balance</span>
          <span style={{fontSize:22,fontWeight:900,color:bal>=0?C.gr:C.re}}>{P(bal)}</span>
        </div>
      </div>
      <div style={{background:C.bg3,border:"1px solid "+C.b,borderRadius:8,padding:"10px 12px",fontSize:11,color:C.d2,lineHeight:1.7}}>
        💡 <strong style={{color:"#fff"}}>Cash Flow ≠ Profit.</strong> Negative balance = nag-invest ka ng stocks. Ang kita ay nasa 📊 Profit tab.
      </div>
    </div>
  );
}

function DashPage({t,salesData,expenses,products,lowStock,unpaidAll,unpaidAmt,setModal,setTab}) {
  const [detail,   setDetail]   = useState(null);
  const [detailFrom,setDFrom]   = useState("");
  const [detailTo,  setDTo]     = useState("");
  const [dashTab,   setDashTab]  = useState("profit");
  const allSales   = DB.getAllSales();
  const todaySales = allSales.filter(s=>s.date===td());
  const todayRev   = todaySales.filter(s=>s.paid).reduce((a,s)=>a+s.total,0);

  // Apply date filter for detail view
  const filterByDate = (list) => {
    let r = list;
    if(detailFrom) r = r.filter(s=>s.date>=detailFrom);
    if(detailTo)   r = r.filter(s=>s.date<=detailTo);
    return r;
  };

  // Main stats use ALL data (no date filter on dashboard overview)
  // Total Sales = sum of (selling_price × qty) for each item sold
  const totalRev = allSales.filter(s=>s.paid).reduce((a,s)=>
    a+(s.items||[]).reduce((b,it)=>b+(+it.price * +it.qty),0),0);
  // CORRECT COGS calculation
  // Determine if item was sold as TINGI or BUO by comparing price to pricePerUnit
  const calcItemCOGS = (it, prods) => {
    const prod = prods.find(p=>p.id===it.pid||p.id===Number(it.pid));
    if(!prod||!+prod.cost) return 0;
    const ppu = +prod.pricePerUnit;
    const upp = +prod.unitsPerPack;
    // If pricePerUnit is set AND item price matches it → sold as TINGI (per piece)
    const soldAsTingi = ppu>0 && upp>0 && Math.abs(+it.price - ppu) < 0.01;
    const costPerSaleUnit = soldAsTingi
      ? +prod.cost / upp    // e.g. ₱900 / 12 = ₱75 per bottle
      : +prod.cost;         // e.g. ₱900 per case sold as BUO
    return costPerSaleUnit * +it.qty;
  };
  const totalCOGS = allSales.filter(s=>s.paid).reduce((a,s)=>
    a+(s.items||[]).reduce((b,it)=>b+calcItemCOGS(it,products),0),0);
  const grossProfit = totalRev - totalCOGS;
  // Operating expenses = REAL expenses only (NOT stock purchases)
  // Stock purchases are tracked separately in stock_purchases table
  const totalExp = expenses
    .filter(e=>e.type!=="Purchased Capital")  // exclude old entries
    .reduce((a,e)=>a+e.amount,0);
  const netProfit   = grossProfit - totalExp;
  const profit      = netProfit;

  // Detail modal: filtered by date range
  const dSales    = filterByDate(allSales.filter(s=>s.paid));
  const dUnpaid   = filterByDate(unpaidAll);
  const dToday    = filterByDate(todaySales);
  const dRev      = dSales.reduce((a,s)=>a+s.total,0);
  const dCOGS     = dSales.reduce((a,s)=>(s.items||[]).reduce((b,it)=>{
    const p=products.find(pr=>pr.id===it.pid||pr.id===Number(it.pid));
    return b+calcItemCOGS(it,products);
  },a),0);
  const dGross    = dRev-dCOGS;
  const dExp      = filterByDate(expenses.map(e=>({...e,date:e.date}))).reduce((a,e)=>a+e.amount,0);
  const dNet      = dGross-dExp;

  const detailData = {
    totalRev:  { label:"💰 Gross Profit",    sales:dSales,   total:dGross, gross:dRev, cogs:dCOGS },
    todaySales:{ label:"📅 Benta",           sales:detailFrom?dSales:todaySales, total:detailFrom?dRev:todayRev },
    profit:    { label:"📈 Net Income",      sales:dSales,   total:dNet,   gross:dGross, exp:dExp },
    unpaid:    { label:"⏳ Utang",           sales:dUnpaid,  total:dUnpaid.reduce((a,s)=>a+s.total,0) },
  };
  const dd = detail ? detailData[detail] : null;

  return (
    <div style={colStyle}>
      {/* Alerts - clickable */}
      <DailySummary sales={DB.getAllSales()} expenses={expenses}/>

      {products.length===0&&(
        <div style={{background:"#071428",border:"2px dashed "+C.bl,borderRadius:12,
          padding:"24px 20px",textAlign:"center"}}>
          <div style={{fontSize:44,marginBottom:10}}>📦</div>
          <div style={{fontSize:16,fontWeight:800,color:"#fff",marginBottom:6}}>Wala pang produkto</div>
          <div style={{fontSize:12,color:C.d2,lineHeight:1.6,marginBottom:16}}>I-add muna ang iyong mga paninda bago makapagbenta!</div>
          <button onClick={()=>setTab("inventory")}
            style={{...bSt(C.bl,"#fff"),padding:"12px 24px",fontSize:14,fontWeight:800,borderRadius:10}}>
            📦 Pumunta sa Imbentaryo
          </button>
        </div>
      )}

      {lowStock.length>0 &&
        <div onClick={()=>setTab("reorder")} style={{background:C.ad,border:"1px solid "+C.am,borderRadius:10,padding:"12px 16px",display:"flex",alignItems:"center",gap:10,cursor:"pointer"}}>
          <span style={{fontSize:22}}>⚠️</span>
          <div style={{flex:1}}><div style={{fontSize:13,fontWeight:800,color:C.am}}>{lowStock.length} produkto kulang sa stock!</div><div style={{fontSize:11,color:C.d2}}>Tap para makita ang reorder list</div></div>
          <span style={{color:C.am,fontSize:18}}>→</span>
        </div>}
      {unpaidAll.length>0 &&
        <div onClick={()=>setTab("payments")} style={{background:C.bd,border:"1px solid "+C.bl,borderRadius:10,padding:"12px 16px",display:"flex",alignItems:"center",gap:10,cursor:"pointer"}}>
          <span style={{fontSize:22}}>📋</span>
          <div style={{flex:1}}><div style={{fontSize:13,fontWeight:800,color:C.bl}}>{unpaidAll.length} hindi pa bayad — {P(unpaidAmt)}</div><div style={{fontSize:11,color:C.d2}}>Tap para kolektahin ang utang</div></div>
          <span style={{color:C.bl,fontSize:18}}>→</span>
        </div>}

      {/* BIG Magbenta */}
      <div onClick={()=>setTab("quicksale")} style={{background:"linear-gradient(135deg,#071f17,#0a2a1e)",border:"2px solid "+C.gr,borderRadius:14,padding:"18px 20px",cursor:"pointer",display:"flex",alignItems:"center",gap:14,boxShadow:"0 4px 20px "+C.gr+"30"}}>
        <span style={{fontSize:40}}>⚡</span>
        <div style={{flex:1}}><div style={{fontSize:22,fontWeight:800,color:C.gr}}>MAGBENTA</div><div style={{fontSize:12,color:C.d2,marginTop:2}}>Tap produkto → Dami → Done!</div></div>
        <span style={{fontSize:28,color:C.gr}}>→</span>
      </div>

      {/* Dashboard tabs: Profit vs Cash Flow */}
      <div style={{display:"flex",background:C.bg2,border:"1px solid "+C.b,borderRadius:10,overflow:"hidden"}}>
        {[{id:"profit",l:"📊 Profit"},  {id:"cashflow",l:"💵 Cash Flow"}].map((tb,i)=>(
          <button key={tb.id} onClick={()=>setDashTab(tb.id)}
            style={{flex:1,padding:"10px",background:dashTab===tb.id?C.bg3:"transparent",
              border:"none",borderBottom:dashTab===tb.id?"2px solid "+(tb.id==="profit"?C.am:C.cy):"2px solid transparent",
              color:dashTab===tb.id?"#fff":C.d2,fontSize:13,fontWeight:dashTab===tb.id?700:400,cursor:"pointer"}}>
            {tb.l}
          </button>
        ))}
      </div>

      {dashTab==="profit"&&(
        <Grid2>
          <ClickStatCard v={P(grossProfit)} label="Gross Profit"    sub={"Sales "+P(totalRev)+" − COGS "+P(totalCOGS)}  color={C.am}  icon="💰" onClick={()=>setDetail("totalRev")}/>
          <ClickStatCard v={P(todayRev)}    label="Benta Ngayon"    sub={todaySales.length+" txn ngayon"}                color={C.cy}  icon="📅" onClick={()=>setDetail("todaySales")}/>
          <ClickStatCard v={P(netProfit)}   label="Net Profit"      sub={netProfit>=0?"Gross − Expenses":"⚠️ Lugi"}       color={netProfit>=0?C.gr:C.re} icon="📈" onClick={()=>setDetail("profit")}/>
          <ClickStatCard v={P(unpaidAmt)}   label="Utang"           sub={unpaidAll.length+" pending"}                    color={C.re}  icon="⚠️" onClick={()=>setDetail("unpaid")}/>
        </Grid2>
      )}

      {dashTab==="cashflow"&&<CashFlowPanel totalRev={totalRev} totalExp={totalExp}/>}

      <Card title={"📋 "+t.recSales} right={<button style={{...gBtn(),fontSize:11}} onClick={()=>setTab("sales")}>Lahat →</button>}>
        <Tbl cols={[t.cust,t.date,t.total,t.status]} rows={[...salesData.items].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5).map(s=>[
          <B>{s.cust}</B>,
          <span style={{fontSize:11,background:C.bg3,padding:"2px 6px",borderRadius:4,color:C.d2}}>{s.date}</span>,
          <span style={{color:C.am,fontWeight:800,fontSize:14}}>{P(s.total)}</span>,
          <Chip c={s.paid?"green":"red"}>{s.paid?t.paid:t.unpaid}</Chip>
        ])}/>
      </Card>

      {/* Detail Modal with date filter */}
      {dd && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:200}}>
          <div style={{background:C.bg2,border:"1px solid "+C.b2,borderRadius:"14px 14px 0 0",padding:"18px 16px 36px",width:"100%",maxWidth:540,maxHeight:"88vh",overflowY:"auto"}}>
            {/* Header */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
              <span style={{fontSize:15,fontWeight:800,color:"#fff"}}>{dd.label}</span>
              <button onClick={()=>{setDetail(null);setDFrom("");setDTo("");}} style={{background:"none",border:"none",color:C.d2,fontSize:24,cursor:"pointer"}}>×</button>
            </div>

            {/* Date range filter */}
            <div style={{background:C.bg3,border:"1px solid "+(detailFrom?C.am:C.b),borderRadius:9,padding:"10px 12px",marginBottom:12}}>
              <div style={{fontSize:11,fontWeight:700,color:detailFrom?C.am:C.d2,marginBottom:6,textTransform:"uppercase"}}>
                📅 {detailFrom?"Custom date range (active)":"Filter by date (optional)"}
              </div>
              <div style={{display:"flex",gap:6,alignItems:"center"}}>
                <input type="date" style={{...iSt(),flex:1,padding:"6px 8px",fontSize:12}} value={detailFrom} onChange={e=>setDFrom(e.target.value)}/>
                <span style={{color:C.d2,fontSize:12,flexShrink:0}}>–</span>
                <input type="date" style={{...iSt(),flex:1,padding:"6px 8px",fontSize:12}} value={detailTo} onChange={e=>setDTo(e.target.value)}/>
                {(detailFrom||detailTo)&&<button style={{...gBtn(),color:C.re,padding:"4px 8px",fontSize:11}} onClick={()=>{setDFrom("");setDTo("");}}>✕</button>}
              </div>
            </div>

            {/* Profit breakdown for relevant cards */}
            {(detail==="totalRev"||detail==="profit")&&(
              <div style={{background:C.bg3,borderRadius:8,padding:"12px",marginBottom:12}}>
                {detail==="totalRev"&&<>
                  <div style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid "+C.b}}>
                    <span style={{color:C.d2,fontSize:12}}>💰 Total Sales (Income)</span>
                    <span style={{color:C.am,fontWeight:700}}>{P(dd.gross||0)}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid "+C.b}}>
                    <span style={{color:C.d2,fontSize:12}}>📦 Cost of Goods Sold (COGS)</span>
                    <span style={{color:C.re,fontWeight:700}}>−{P(dd.cogs||0)}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",paddingTop:6}}>
                    <span style={{color:"#fff",fontWeight:800}}>💰 Gross Profit</span>
                    <span style={{color:C.am,fontWeight:900,fontSize:16}}>{P(dd.total)}</span>
                  </div>
                </>}
                {detail==="profit"&&<>
                  <div style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid "+C.b}}>
                    <span style={{color:C.d2,fontSize:12}}>💰 Gross Profit</span>
                    <span style={{color:C.am,fontWeight:700}}>{P(dd.gross||0)}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid "+C.b}}>
                    <span style={{color:C.d2,fontSize:12}}>🧾 Total Expenses</span>
                    <span style={{color:C.re,fontWeight:700}}>−{P(dd.exp||0)}</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",paddingTop:6}}>
                    <span style={{color:"#fff",fontWeight:800}}>📈 Net Income</span>
                    <span style={{color:dd.total>=0?C.gr:C.re,fontWeight:900,fontSize:16}}>{P(dd.total)}</span>
                  </div>
                </>}
              </div>
            )}

            <div style={{fontSize:12,color:C.d2,marginBottom:8,fontWeight:700}}>
              {dd.sales.length} transactions{detailFrom?" (filtered)":""}:
            </div>
            {dd.sales.length===0
              ? <div style={{textAlign:"center",color:C.d2,padding:"24px"}}>Walang transactions sa period na ito.</div>
              : dd.sales.map(s=>(
                <div key={s.id} style={{background:C.bg3,borderRadius:8,padding:"10px 12px",marginBottom:8}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                    <span style={{fontSize:13,fontWeight:700,color:"#fff"}}>{s.cust}</span>
                    <span style={{fontSize:14,fontWeight:800,color:C.am}}>{P(s.total)}</span>
                  </div>
                  <div style={{fontSize:11,color:C.d2,marginBottom:4}}>{s.date} · {s.method}</div>
                  {s.items&&s.items.map((it,i)=>{
                    const pName=it.name||(products&&products.find(p=>p.id===it.pid||p.id===Number(it.pid))||{}).name)||"Item #"+it.pid;
                    const itemCOGS=calcItemCOGS(it,products);
                    const itemProfit=(+it.price*+it.qty)-itemCOGS;
                    return (
                      <div key={i} style={{fontSize:11,paddingLeft:8,paddingBottom:4,borderBottom:"1px dashed "+C.b,marginBottom:3}}>
                        <div style={{color:"#fff"}}>• {pName} ×{it.qty} @ {P(it.price)} = <span style={{color:C.am,fontWeight:600}}>{P(it.price*it.qty)}</span></div>
                        <div style={{color:C.d2,paddingLeft:8}}>COGS: {P(itemCOGS)} · Profit: <span style={{color:itemProfit>=0?C.gr:C.re,fontWeight:600}}>{P(itemProfit)}</span></div>
                      </div>
                    );
                  })}
                </div>
              ))}
            <div style={{borderTop:"1px solid "+C.b,paddingTop:10,display:"flex",justifyContent:"space-between",fontWeight:800}}>
              <span style={{color:"#fff"}}>TOTAL</span>
              <span style={{color:C.am,fontSize:16}}>{P(dd.total)}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// CartItem - separate component to prevent re-render glitch
function CartItem({item, onUpdate}) {
  const [localQty, setLocalQty] = React.useState(item.qty);
  React.useEffect(()=>{ setLocalQty(item.qty); }, [item.qty]);
  const commit = (val) => {
    const n = +val;
    if(n>0) onUpdate(item.name, n);
    else if(n<=0) onUpdate(item.name, 0);
  };
  return (
    <div style={{display:"flex",alignItems:"center",padding:"8px 14px",borderBottom:"1px solid "+C.b,gap:8}}>
      <div style={{flex:1}}>
        <div style={{fontSize:13,fontWeight:600,color:"#fff"}}>{item.name}</div>
        <div style={{fontSize:11,color:C.d2}}>{P(item.price)} × {item.qty} = <span style={{color:C.cy,fontWeight:700}}>{P(item.price*item.qty)}</span></div>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:4}}>
        <button onMouseDown={e=>{e.stopPropagation();onUpdate(item.name,item.qty-1);}}
          style={{background:C.bg3,border:"1px solid "+C.b2,borderRadius:6,width:30,height:30,color:"#fff",cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}>−</button>
        <input type="number" min="1" value={localQty}
          onChange={e=>setLocalQty(e.target.value)}
          onBlur={e=>commit(e.target.value)}
          onKeyDown={e=>e.key==="Enter"&&commit(localQty)}
          style={{...iSt(),width:46,textAlign:"center",padding:"4px",fontSize:14,height:30}}/>
        <button onMouseDown={e=>{e.stopPropagation();onUpdate(item.name,item.qty+1);}}
          style={{background:C.bl,border:"none",borderRadius:6,width:30,height:30,color:"#fff",cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
        <button onMouseDown={e=>{e.stopPropagation();onUpdate(item.name,0);}}
          style={{background:"none",border:"none",color:C.re,cursor:"pointer",fontSize:20,padding:"0 2px"}}>✕</button>
      </div>
    </div>
  );
}

function QuickSale({t,products,cats,addSale,setTab}) {
  const [search,  setSearch]  = useState("");
  const [selCat,  setSelCat]  = useState("all");
  const [cart,    setCart]    = useState([]);
  const [selProd, setSelProd] = useState(null);  // TAP 1 selected product
  const [selMode, setSelMode] = useState(null);  // "whole" or "tingi"
  const [selVar,  setSelVar]  = useState("");    // selected variant
  const [customQty,setCustomQty]=useState("1");
  const [cust,    setCust]    = useState("");
  const [method,  setMethod]  = useState("Cash");
  const [isPaid,  setIsPaid]  = useState(true);
  const [done,    setDone]    = useState(false);
  const [lastAmt, setLastAmt] = useState(0);

  const filtered = useMemo(()=>{
    // Show ALL products — zero stock shown with warning
    let list = [...products];
    if(selCat!=="all") list = list.filter(p=>p.cat===selCat);
    if(search.trim()) list = list.filter(p=>p.name.toLowerCase().includes(search.toLowerCase())||(p.sku&&p.sku.toLowerCase()).includes(search.toLowerCase()));
    // Sort: in-stock first, out-of-stock last
    return list.sort((a,b)=>(b.stock>0?1:0)-(a.stock>0?1:0));
  },[products,selCat,search]);

  const cartTotal = cart.reduce((a,i)=>a+i.price*i.qty, 0);
  const allCats   = ["all",...new Set(products.map(p=>p.cat))];

  // Has tingi option?
  const hasTingi = p => p.unitsPerPack>0 && p.pricePerUnit>0;

  // TAP 1 — select product
  const tapProduct = p => {
    setSelProd(p);
    setSelMode(null);
    setSelVar(p.variants?.[0]||"");
    setCustomQty("1");
  };

  // TAP 2a — choose whole or tingi
  const tapMode = mode => setSelMode(mode);

  // TAP 2b — add to cart
  const addToCart = (qty, price, label) => {
    if(selProd.stock<=0) {
      if(!window.confirm("⚠️ Wala nang stock ang "+selProd.name+"! Ituloy pa rin?")) return;
    }
    const cartItem = {
      pid: selProd.id,
      name: selProd.name + (selVar?" - "+selVar:"") + (label?" ("+label+")":""),
      qty: qty,
      price: price,
      unit: label||selProd.unit||"piraso"
    };
    setCart(c=>{
      const ex = c.find(i=>i.pid===selProd.id&&i.name===cartItem.name);
      return ex ? c.map(i=>i.name===cartItem.name?{...i,qty:i.qty+qty}:i) : [...c,cartItem];
    });
    setSelProd(null);
    setSelMode(null);
    setCustomQty("1");
  };

  // Update qty in cart
  const updateCartQty = (name, newQty) => {
    if(newQty<=0) setCart(c=>c.filter(i=>i.name!==name));
    else setCart(c=>c.map(i=>i.name===name?{...i,qty:newQty}:i));
  };

  // TAP 3 — confirm sale
  const confirmSale = () => {
    if(!cart.length) return;
    addSale({
      date: td(),
      cust: cust.trim()||"Walk-in",
      items: cart.map(i=>({pid:i.pid,name:i.name,qty:i.qty,price:i.price,unit:i.unit})),
      total: cartTotal,
      paid: isPaid,
      method
    });
    setLastAmt(cartTotal);
    setCart([]);
    setCust("");
    setDone(true);
    // User must tap to dismiss
  };

  const step = selProd ? (selMode===null? "mode" : "qty") : "browse";

  return (
    <div style={{...colStyle,maxWidth:600,margin:"0 auto"}}>
      {/* Done notification - BIG fullscreen flash */}
      {done && (
        <div style={{position:"fixed",inset:0,background:"rgba(7,31,23,0.96)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",zIndex:500,animation:"fadeIn 0.2s ease"}}>
          <div style={{fontSize:72,marginBottom:16}}>✅</div>
          <div style={{fontSize:28,fontWeight:800,color:C.gr,marginBottom:8}}>NABENTA!</div>
          <div style={{fontSize:48,fontWeight:900,color:C.am,marginBottom:8}}>{P(lastAmt)}</div>
          <div style={{fontSize:14,color:C.d2,marginBottom:32}}>Naitala na ang benta</div>
          <div style={{display:"flex",gap:12}}>
            <button onClick={()=>setDone(false)} style={{...bSt(C.gr,"#000"),padding:"14px 32px",fontSize:16,fontWeight:800,borderRadius:12}}>
              ➕ Benta Pa
            </button>
          </div>
        </div>
      )}

      <BackBtn setTab={setTab}/>
      {/* Header - Hanapin Produkto */}
      <div style={{background:C.bg3,border:"1px solid "+C.b,borderRadius:10,padding:"12px 14px"}}>
        <div style={{fontSize:13,fontWeight:800,color:C.gr,marginBottom:8}}>🔍 Hanapin ang Produkto</div>
        <input style={{...iSt(),fontSize:15,padding:"12px 14px",border:"2px solid "+C.gr}}
          placeholder="I-search ang produkto... (lahat ay makikita)"
          value={search} onChange={e=>setSearch(e.target.value)} autoFocus/>
      </div>

      {/* Step indicator */}
      <div style={{display:"flex",background:C.bg2,border:"1px solid "+C.b,borderRadius:10,overflow:"hidden"}}>
        {[{n:"1",l:"Hanapin/Piliin",active:step==="browse"},{n:"2",l:"Dami/Uri",active:step==="mode"||step==="qty"},{n:"3",l:"Bayad",active:cart.length>0&&step==="browse"}].map((x,i)=>(
          <div key={i} style={{flex:1,padding:"8px 4px",textAlign:"center",background:x.active?"#22d3a020":"transparent",borderRight:i<2?"1px solid "+C.b:"none"}}>
            <div style={{fontSize:14,fontWeight:800,color:x.active?C.gr:C.d3}}>TAP {x.n}</div>
            <div style={{fontSize:10,color:C.d2}}>{x.l}</div>
          </div>
        ))}
      </div>

      {/* Category pills */}
      <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:2}}>
        {allCats.map(c=><button key={c} onClick={()=>setSelCat(c)}
          style={{padding:"5px 12px",borderRadius:20,border:"1px solid "+(selCat===c?C.bl:C.b2),
            background:selCat===c?C.bd:"transparent",color:selCat===c?C.bl:C.d2,
            fontSize:12,fontWeight:600,cursor:"pointer",whiteSpace:"nowrap",flexShrink:0}}>
          {c==="all"?"Lahat":c}
        </button>)}
      </div>

      {/* TAP 1 — Product grid (ALWAYS visible so you can keep adding) */}
  

      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
        {filtered.map(p=>{
          const inCart = cart.filter(i=>i.pid===p.id);
          const cartQty = inCart.reduce((a,i)=>a+i.qty,0);
          const isSelected = (selProd&&selProd.id)===p.id;
          return (
            <button key={p.id} onClick={()=>tapProduct(p)}
              style={{background:p.stock<=0?C.rd:isSelected?C.gd:cartQty>0?"#22d3a010":C.bg2,
                border:"2px solid "+(p.stock<=0?C.re:isSelected?C.gr:cartQty>0?C.gr+"80":C.b),
                borderRadius:10,padding:"12px",cursor:"pointer",textAlign:"left",position:"relative",transition:"all 0.1s",opacity:p.stock<=0?0.7:1}}>
              {cartQty>0 && <div style={{position:"absolute",top:6,right:6,background:C.gr,color:"#000",borderRadius:20,fontSize:10,fontWeight:800,padding:"1px 7px"}}>×{cartQty}</div>}
              {p.stock<=0 && <div style={{background:C.re,color:"#fff",borderRadius:5,fontSize:9,fontWeight:800,padding:"2px 7px",display:"inline-block",marginBottom:4}}>❌ WALA NA</div>}
              <div style={{fontSize:13,fontWeight:700,color:p.stock<=0?"#999":"#fff",lineHeight:1.3,marginBottom:3}}>{p.name}</div>
              {(p.variants&&p.variants.length)>0 && <div style={{fontSize:10,color:C.pu,marginBottom:2}}>{p.variants.length} variants</div>}
              <div style={{fontSize:16,fontWeight:800,color:p.stock<=0?C.d3:C.gr}}>{P(p.price)}</div>
              {hasTingi(p) && <div style={{fontSize:10,color:C.am,marginTop:2}}>Tingi: {P(p.pricePerUnit)}/{p.unit||"pc"}</div>}
              <div style={{fontSize:10,color:p.stock<=0?C.re:C.d2,fontWeight:p.stock<=0?700:400,marginTop:2}}>
                {p.stock<=0 ? "Out of Stock — pwede pa ring ibenta" : "Stock: "+p.stock}
              </div>
            </button>
          );
        })}
        {filtered.length===0 && <div style={{gridColumn:"1/-1",padding:"32px",textAlign:"center",color:C.d2}}>Walang produkto na nahanap.</div>}
      </div>

      {/* TAP 2 — Mode selector (whole vs tingi) */}
      {step==="mode" && selProd && (
        <div style={{background:C.bg2,border:"2px solid "+C.gr,borderRadius:12,padding:"16px",position:"sticky",bottom:0}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
            <div style={{fontSize:15,fontWeight:800,color:"#fff"}}>{selProd.name}</div>
            <button onClick={()=>setSelProd(null)} style={{background:"none",border:"none",color:C.re,fontSize:22,cursor:"pointer"}}>×</button>
          </div>

          {/* Variant selector */}
          {(selProd.variants&&selProd.variants.length)>0 && (
            <div style={{marginBottom:12}}>
              <div style={{fontSize:11,fontWeight:700,color:C.d2,marginBottom:6,textTransform:"uppercase"}}>Variant / Uri:</div>
              <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                {selProd.variants.map(v=>(
                  <button key={v} onClick={()=>setSelVar(v)}
                    style={{padding:"6px 14px",borderRadius:20,border:"1px solid "+(selVar===v?C.pu:C.b2),
                      background:selVar===v?C.pd:"transparent",color:selVar===v?C.pu:C.d2,
                      fontSize:13,fontWeight:600,cursor:"pointer"}}>
                    {v}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div style={{fontSize:11,fontWeight:700,color:C.d2,marginBottom:8,textTransform:"uppercase"}}>Ibebenta bilang:</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <button onClick={()=>tapMode("whole")}
              style={{padding:"14px",borderRadius:10,border:"2px solid "+C.bl,background:C.bd,color:C.bl,fontWeight:700,fontSize:14,cursor:"pointer",textAlign:"center"}}>
              <div style={{fontSize:16}}>📦</div>
              <div style={{fontSize:13,fontWeight:800,color:C.bl,marginTop:3,textTransform:"uppercase"}}>
                {getPackLabel(selProd)}
              </div>
              <div style={{fontSize:15,color:C.gr,fontWeight:800,marginTop:3}}>
                {selProd.unitsPerPack>0&&selProd.pricePerUnit>0 ? P(selProd.unitsPerPack*selProd.pricePerUnit) : P(selProd.price)}
              </div>
              {selProd.unitsPerPack>0&&selProd.pricePerUnit>0&&(
                <div style={{fontSize:10,color:C.d2,marginTop:2}}>{selProd.unitsPerPack} {selProd.unit||"pcs"}×{P(selProd.pricePerUnit)}</div>
              )}
            </button>
            {hasTingi(selProd) && (
              <button onClick={()=>tapMode("tingi")}
                style={{padding:"14px",borderRadius:10,border:"2px solid "+C.am,background:C.ad,color:C.am,fontWeight:700,fontSize:14,cursor:"pointer",textAlign:"center"}}>
                <div style={{fontSize:16}}>✂️</div>
                <div style={{fontSize:13,fontWeight:800,color:C.am,marginTop:3,textTransform:"uppercase"}}>
                  {selProd.unit||"piraso"}
                </div>
                <div style={{fontSize:15,color:C.am,fontWeight:800,marginTop:3}}>{P(selProd.pricePerUnit)}</div>
                <div style={{fontSize:10,color:C.d2,marginTop:2}}>bawat {selProd.unit||"piraso"}</div>
              </button>
            )}
            {!hasTingi(selProd) && (
              <button onClick={()=>tapMode("whole")}
                style={{padding:"14px",borderRadius:10,border:"1px solid "+C.b2,background:C.bg3,color:C.d2,fontSize:12,cursor:"pointer"}}>
                (Walang tingi setup)
              </button>
            )}
          </div>
        </div>
      )}

      {/* TAP 2b — Quantity after mode selected */}
      {step==="qty" && selProd && selMode && (
        <div style={{background:C.bg2,border:"2px solid "+(selMode==="tingi"?C.am:C.bl),borderRadius:12,padding:"16px",position:"sticky",bottom:0}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
            <div>
              <div style={{fontSize:14,fontWeight:800,color:"#fff"}}>{selProd.name}{selVar?" — "+selVar:""}</div>
              <div style={{fontSize:13,color:selMode==="tingi"?C.am:C.bl,fontWeight:700}}>
                {selMode==="tingi"?`${P(selProd.pricePerUnit)} bawat ${selProd.unit||"piraso"}`:`${P(selProd.price)} buo`}
              </div>
            </div>
            <button onClick={()=>setSelMode(null)} style={{background:"none",border:"none",color:C.d2,fontSize:18,cursor:"pointer"}}>←</button>
          </div>

          <div style={{fontSize:11,fontWeight:700,color:C.d2,marginBottom:8,textTransform:"uppercase"}}>
            Ilang {selMode==="tingi"?(selProd.unit||"piraso"):getPackLabel(selProd)}?
          </div>

          {/* Quick qty buttons */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:12}}>
            {[1,2,3,4,5,6,10,12].map(q=>(
              <button key={q} onClick={()=>addToCart(q,
                  selMode==="tingi" ? selProd.pricePerUnit
                    : (selProd.unitsPerPack>0&&selProd.pricePerUnit>0 ? selProd.unitsPerPack*selProd.pricePerUnit : selProd.price),
                  selMode==="tingi" ? selProd.unit : null)}
                style={{padding:"14px 6px",borderRadius:10,border:"1px solid "+C.b2,
                  background:C.bg3,color:"#fff",fontSize:20,fontWeight:800,cursor:"pointer"}}>
                {q}
              </button>
            ))}
          </div>

          {/* Custom qty input */}
          <div style={{display:"flex",gap:8}}>
            <input type="number" min="1" placeholder="Custom dami..." style={{...iSt(),flex:1,fontSize:16}}
              value={customQty} onChange={e=>setCustomQty(e.target.value)}
              onKeyDown={e=>{if(e.key==="Enter"&&+customQty>0){
                  const wp=selProd.unitsPerPack>0&&selProd.pricePerUnit>0?selProd.unitsPerPack*selProd.pricePerUnit:selProd.price;
                  addToCart(+customQty,selMode==="tingi"?selProd.pricePerUnit:wp,selMode==="tingi"?selProd.unit:null);
                }}}/>
            <button onClick={()=>{if(+customQty>0){const wp=selProd.unitsPerPack>0&&selProd.pricePerUnit>0?selProd.unitsPerPack*selProd.pricePerUnit:selProd.price;addToCart(+customQty,selMode==="tingi"?selProd.pricePerUnit:wp,selMode==="tingi"?selProd.unit:null);}}}
              style={{...bSt(selMode==="tingi"?C.am:C.bl,"#fff"),padding:"10px 16px",fontSize:14}}>
              + Dagdag
            </button>
          </div>
        </div>
      )}

      {/* TAP 3 — Cart & Checkout (always visible when cart has items) */}
      {cart.length>0 && (
        <div style={{background:C.bg2,border:"1px solid "+C.b,borderRadius:12,overflow:"hidden"}}>
          <div style={{padding:"10px 14px",borderBottom:"1px solid "+C.b,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:13,fontWeight:700,color:"#fff"}}>🛒 Cart ({cart.reduce((a,i)=>a+i.qty,0)} items)</span>
            <span style={{fontSize:16,fontWeight:800,color:C.am}}>{P(cartTotal)}</span>
          </div>
          {cart.map(i=>(
            <CartItem key={i.name} item={i} onUpdate={updateCartQty}/>
          ))}
          <div style={{padding:"12px 14px",display:"flex",flexDirection:"column",gap:8}}>
            <CustomerInput value={cust} onChange={setCust}/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <select style={iSt()} value={method} onChange={e=>setMethod(e.target.value)}>
                {["Cash","GCash","PayMaya","Utang"].map(m=><option key={m}>{m}</option>)}
              </select>
              <select style={iSt()} value={isPaid?"paid":"utang"} onChange={e=>setIsPaid(e.target.value==="paid")}>
                <option value="paid">✓ Bayad</option>
                <option value="utang">Utang</option>
              </select>
            </div>
            <button onClick={confirmSale}
              style={{...bSt(C.gr,"#000"),width:"100%",justifyContent:"center",padding:"16px",fontSize:16,fontWeight:800,borderRadius:10}}>
              ✅ IBENTA — <span style={{color:"#000",fontWeight:900}}>{P(cartTotal)}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
function SalesPage({t,salesData,refreshSales,salesPage,setTab}) {
  const [f,       setF]       = useState("all");
  const [sort,    setSort]    = useState("newest");
  const [dateFrom,setDateFrom]= useState("");
  const [dateTo,  setDateTo]  = useState("");
  const [expandId,setExpandId]= useState(null);
  const rows = useMemo(()=>{
    let list = f==="all"?salesData.items:salesData.items.filter(s=>s.paid===(f==="paid"));
    if(dateFrom) list=list.filter(s=>s.date>=dateFrom);
    if(dateTo)   list=list.filter(s=>s.date<=dateTo);
    return sort==="newest"
      ?[...list].sort((a,b)=>b.date.localeCompare(a.date))
      :[...list].sort((a,b)=>a.date.localeCompare(b.date));
  },[salesData.items,f,sort,dateFrom,dateTo]);
  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
        {["all","paid","unpaid"].map(v=>(
          <button key={v} style={f===v?bSt():gBtn()} onClick={()=>setF(v)}>
            {v==="all"?t.all:v==="paid"?"✅ "+t.paid:"📋 "+t.unpaid}
          </button>
        ))}
        <button style={gBtn()} onClick={()=>setSort(s=>s==="newest"?"oldest":"newest")}>
          {sort==="newest"?"↓ Bago":"↑ Luma"}
        </button>
      </div>
      <div style={{display:"flex",gap:6,alignItems:"center",background:C.bg2,border:"1px solid "+C.b,borderRadius:8,padding:"7px 10px"}}>
        <span style={{fontSize:11,color:C.d2}}>📅</span>
        <input type="date" style={{...iSt(),flex:1,padding:"5px 8px",fontSize:12}} value={dateFrom} onChange={e=>setDateFrom(e.target.value)}/>
        <span style={{color:C.d2,fontSize:11}}>–</span>
        <input type="date" style={{...iSt(),flex:1,padding:"5px 8px",fontSize:12}} value={dateTo} onChange={e=>setDateTo(e.target.value)}/>
        {(dateFrom||dateTo)&&<button style={{...gBtn(),color:C.re,padding:"3px 8px",fontSize:11}} onClick={()=>{setDateFrom("");setDateTo("");}}>✕</button>}
      </div>
      <div style={{fontSize:11,color:C.d2}}>{rows.length} records</div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{display:"flex",gap:6}}>{["all","paid","unpaid"].map(v=><button key={v} style={f===v?bSt():gBtn()} onClick={()=>setF(v)}>{v==="all"?t.all:v==="paid"?t.paid:t.unpaid}</button>)}</div>
        <div style={{fontSize:11,color:C.d2}}>Page {salesPage+1}/{salesData.pages} · {salesData.total} total</div>
      </div>
      <Card>
        {rows.map((s,i)=>(
          <div key={s.id} style={{borderBottom:i<rows.length-1?"1px solid "+C.b:"none"}}>
            <div style={{padding:"10px 14px",display:"flex",alignItems:"center",gap:10,cursor:"pointer"}} onClick={()=>setExpandId(expandId===s.id?null:s.id)}>
              <div style={{flex:1}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <B>{s.cust}</B>
                  <span style={{color:C.gr,fontWeight:700,fontSize:14}}>{P(s.total)}</span>
                </div>
                <div style={{fontSize:11,color:C.d2,marginTop:2}}>{s.date} · {s.method}</div>
                {/* Item summary line */}
                <div style={{fontSize:11,color:C.d2,marginTop:2}}>{(s.items&&s.items.slice)(0,2).map(it=>it.name||"Item").join(", ")}{(s.items&&s.items.length)>2?" +"+( s.items.length-2)+" more":""}</div>
              </div>
              <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
                <Chip c={s.paid?"green":"amber"}>{s.paid?t.paid:t.unpaid}</Chip>
                <span style={{fontSize:10,color:C.d3}}>{expandId===s.id?"▲":"▼"}</span>
              </div>
            </div>
            {expandId===s.id&&(
              <div style={{padding:"8px 14px 12px",background:C.bg3,borderTop:"1px solid "+C.b}}>
                {(s.items&&s.items.map)((it,j)=>(
                  <div key={j} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",fontSize:12}}>
                    <span style={{color:"#fff"}}>{it.name||"Produkto #"+it.pid} <span style={{color:C.d2}}>×{it.qty} {it.unit||""}</span></span>
                    <span style={{color:C.gr,fontWeight:600}}>{P(it.price*it.qty)}</span>
                  </div>
                ))}
                <div style={{borderTop:"1px dashed "+C.b,marginTop:6,paddingTop:6,display:"flex",justifyContent:"space-between",fontWeight:700}}>
                  <span style={{color:C.d2}}>TOTAL</span><span style={{color:C.gr}}>{P(s.total)}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </Card>
      {salesData.pages>1 && <div style={{display:"flex",gap:8,justifyContent:"center"}}>
        <button style={gBtn()} disabled={salesPage===0} onClick={()=>refreshSales(salesPage-1)}>← Prev</button>
        <button style={gBtn()} disabled={salesPage>=salesData.pages-1} onClick={()=>refreshSales(salesPage+1)}>Next →</button>
      </div>}
    </div>
  );
}

function PayPage({t,unpaidAll,salesData,markPaid,togglePaid,addPartialPayment,setTab}) {
  const total = unpaidAll.reduce((a,s)=>a+s.total,0);
  const [expandId,  setExpandId]  = useState(null);
  const [partialAmt,setPartialAmt]= useState("");
  const [filter,    setFilter]    = useState("unpaid");
  const [sortPay,   setSortPay]   = useState("newest");
  const allSales = DB.getAllSales();
  const shownRaw = filter==="unpaid" ? unpaidAll : filter==="paid" ? allSales.filter(s=>s.paid) : allSales;
  const shown = [...shownRaw].sort((a,b)=>sortPay==="newest"?b.date.localeCompare(a.date):a.date.localeCompare(b.date));

  const handlePartial = (s) => {
    const amt = +partialAmt;
    if(!amt||amt<=0) return alert("Lagyan ng halaga.");
    const remaining = s.total - (s.partialPaid||0);
    if(amt > remaining) return alert("Mas malaki sa natitirang bayad na "+P(remaining));
    addPartialPayment(s.id, amt);
    setPartialAmt("");
    setExpandId(null);
  };

  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>
      {unpaidAll.length>0 && <div style={{background:C.ad,border:"1px solid "+C.am,borderRadius:8,padding:"10px 14px",color:C.am,fontWeight:600,fontSize:13}}>
        ⚠️ {unpaidAll.length} hindi pa bayad — <span style={{color:C.re,fontWeight:900}}>{P(total)}</span>
      </div>}

      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        {["unpaid","paid","all"].map(f=>(
          <button key={f} style={filter===f?bSt():gBtn()} onClick={()=>setFilter(f)}>
            {f==="unpaid"?"📋 Utang":f==="paid"?"✅ Bayad":"Lahat"}
          </button>
        ))}
        <button style={sortPay==="newest"?bSt():gBtn()} onClick={()=>setSortPay(s=>s==="newest"?"oldest":"newest")}>
          {sortPay==="newest"?"↓ Bago":"↑ Luma"}
        </button>
      </div>

      <div style={colStyle}>
        {shown.length===0 ? (
          <Card><div style={{padding:"32px",textAlign:"center",color:C.d2}}>{t.allSettled}</div></Card>
        ) : shown.map(s=>{
          const remaining = s.total - (s.partialPaid||0);
          const pct = s.partialPaid ? Math.round((s.partialPaid/s.total)*100) : 0;
          return (
            <div key={s.id} style={{background:C.bg2,border:"1px solid "+(s.paid?C.gr+"40":C.b),borderRadius:10,overflow:"hidden"}}>
              {/* Header */}
              <div style={{padding:"12px 14px",display:"flex",alignItems:"center",gap:10}} onClick={()=>setExpandId(expandId===s.id?null:s.id)}>
                <div style={{flex:1}}>
                  <div style={{fontSize:15,fontWeight:800,color:"#fff"}}>{s.cust}</div>
                  <div style={{fontSize:11,color:C.d2}}>{s.date} · {s.method}</div>
                  {s.partialPaid>0&&!s.paid&&(
                    <div style={{fontSize:11,color:C.am,marginTop:2}}>
                      Nabayad: {P(s.partialPaid)} / {P(s.total)} ({pct}%)
                    </div>
                  )}
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:16,fontWeight:800,color:s.paid?C.am:C.re}}>{P(s.paid?s.total:remaining)}</div>
                  <div style={{fontSize:10,color:C.d2}}>{s.paid?"Bayad na":"Natitirang bayad"}</div>
                </div>
                <span style={{color:C.d2,fontSize:18}}>{expandId===s.id?"▲":"▼"}</span>
              </div>

              {/* Progress bar for partial */}
              {s.partialPaid>0&&!s.paid&&(
                <div style={{height:4,background:C.bg3}}>
                  <div style={{height:4,background:C.am,width:pct+"%",transition:"width 0.3s"}}/>
                </div>
              )}

              {/* Expanded detail */}
              {expandId===s.id && (
                <div style={{padding:"12px 14px",borderTop:"1px solid "+C.b}}>
                  {/* Items bought */}
                  <div style={{fontSize:11,fontWeight:700,color:C.d2,textTransform:"uppercase",marginBottom:8}}>Mga Binili:</div>
                  {s.items&&s.items.map((it,i)=>{
                    const nm = it.name || "Produkto #"+it.pid;
                    return (
                      <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid "+C.b}}>
                        <div>
                          <div style={{fontSize:13,color:"#fff",fontWeight:600}}>{nm}</div>
                          <div style={{fontSize:11,color:C.d2}}>{it.qty} {it.unit||"pc"} × {P(it.price)}</div>
                        </div>
                        <span style={{color:C.gr,fontWeight:700,fontSize:13}}>{P(it.price*it.qty)}</span>
                      </div>
                    );
                  })}
                  <div style={{display:"flex",justifyContent:"space-between",padding:"8px 0",fontWeight:800}}>
                    <span style={{color:C.d2}}>TOTAL</span>
                    <span style={{color:C.gr}}>{P(s.total)}</span>
                  </div>
                  {s.partialPaid>0&&(
                    <div style={{display:"flex",justifyContent:"space-between",padding:"4px 0",fontSize:12}}>
                      <span style={{color:C.d2}}>Nabayad na</span>
                      <span style={{color:C.am}}>−{P(s.partialPaid)}</span>
                    </div>
                  )}
                  {!s.paid&&(
                    <div style={{display:"flex",justifyContent:"space-between",padding:"4px 0",fontSize:13,fontWeight:700}}>
                      <span style={{color:"#fff"}}>Natitirang Bayad</span>
                      <span style={{color:C.re}}>{P(remaining)}</span>
                    </div>
                  )}

                  {/* Action buttons */}
                  {!s.paid&&(
                    <div style={{marginTop:12,display:"flex",flexDirection:"column",gap:8}}>
                      {/* Full payment */}
                      <button onClick={()=>togglePaid(s.id,true)}
                        style={{...bSt(C.gr,"#000"),width:"100%",justifyContent:"center",padding:"12px",fontSize:14,fontWeight:800}}>
                        ✅ BAYAD NA — {P(remaining)}
                      </button>
                      {/* Partial payment */}
                      <div style={{display:"flex",gap:8}}>
                        <input type="number" placeholder={"Partial na bayad (max "+P(remaining)+")"} style={{...iSt(),flex:1}}
                          value={partialAmt} onChange={e=>setPartialAmt(e.target.value)}/>
                        <button onClick={()=>handlePartial(s)}
                          style={{...bSt(C.am,"#000"),padding:"10px 14px",fontSize:12,fontWeight:700}}>
                          Partial
                        </button>
                      </div>
                    </div>
                  )}
                  {s.paid&&(
                    <button onClick={()=>togglePaid(s.id,false)}
                      style={{...gBtn(),marginTop:10,color:C.re,width:"100%",justifyContent:"center"}}>
                      ↩ I-Utang ulit
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
function InvPage({t,products,cats,dupProduct,editProduct,delProduct,adjStock,setModal,setTab}) {
  const [search,setSearch]=useState("");
  const [selCat,setSelCat]=useState("all");
  const [view,setView]=useState("grid");
  const filtered=useMemo(()=>{
    let list=products;
    if(selCat!=="all") list=list.filter(p=>p.cat===selCat);
    if(search.trim()) list=list.filter(p=>p.name.toLowerCase().includes(search.toLowerCase())||(p.sku&&p.sku.toLowerCase()).includes(search.toLowerCase()));
    return list;
  },[products,selCat,search]);
  const catList=["all",...new Set(products.map(p=>p.cat))];
  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>
      <input style={{...iSt(),fontSize:15,padding:"13px 16px",border:`1px solid ${C.bl}`}} placeholder={t.search} value={search} onChange={e=>setSearch(e.target.value)} autoFocus/>
      <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:2}}>
        {catList.map(c=>{const catObj=cats.find(x=>x.name===c);return(<button key={c} onClick={()=>setSelCat(c)} style={{padding:"5px 14px",borderRadius:20,border:`1px solid ${selCat===c?((catObj&&catObj.color)||C.bl):C.b2}`,background:selCat===c?`${(catObj&&catObj.color)||C.bl}20`:"transparent",color:selCat===c?((catObj&&catObj.color)||C.bl):C.d2,fontSize:12,fontWeight:600,cursor:"pointer",whiteSpace:"nowrap",flexShrink:0}}>{c==="all"?"🏷️ Lahat":c}</button>);})}
        <button style={{...gBtn(),fontSize:11,flexShrink:0}} onClick={()=>setView(v=>v==="grid"?"list":"grid")}>{view==="grid"?"📋 List":"⊞ Grid"}</button>
      </div>
      <div style={{fontSize:12,color:C.d2}}>{filtered.length} produkto</div>
      {view==="grid"?(
        <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10}}>
          {filtered.map(p=>(
            <div key={p.id} style={{background:C.bg2,border:`1px solid ${p.stock<=p.min?C.re:C.b}`,borderRadius:10,padding:"12px",position:"relative"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                <div style={{flex:1,minWidth:0}}><div style={{fontSize:13,fontWeight:700,color:"#fff",lineHeight:1.3,marginBottom:2}}>{p.name}</div><div style={{fontSize:10,color:C.d3,fontFamily:"monospace"}}>{p.sku}</div></div>
                <Chip c={p.stock<=p.min?"red":"green"}>{p.stock}</Chip>
              </div>
              <div style={{fontSize:15,fontWeight:800,color:C.gr,marginBottom:2}}>{P(p.price)}</div>
              {p.unitsPerPack>0&&p.pricePerUnit>0&&(
                <div style={{fontSize:10,color:C.am,marginBottom:6,lineHeight:1.6,background:C.bg3,borderRadius:6,padding:"5px 8px"}}>
                  <div>📦 {p.unitsPerPack} units × {P(p.pricePerUnit)} = <strong style={{color:C.gr}}>{P(p.unitsPerPack*p.pricePerUnit)}</strong></div>
                  <div>💸 Cost: {P(p.cost)} → 💚 Tubo: <strong style={{color:C.gr}}>{P((p.unitsPerPack*p.pricePerUnit)-p.cost)}</strong> ({(((p.unitsPerPack*p.pricePerUnit)-p.cost)/(p.unitsPerPack*p.pricePerUnit)*100).toFixed(0)}%)</div>
                </div>
              )}
              <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                <button style={{...gBtn(),fontSize:10,padding:"3px 8px"}} onClick={()=>adjStock(p.id,-1)}>−</button>
                <button style={{...bSt(),fontSize:10,padding:"3px 8px"}} onClick={()=>adjStock(p.id,+1)}>+</button>
                <button style={{...gBtn(),fontSize:10,padding:"3px 8px"}} onClick={()=>setModal({type:"editProd",data:p})}>✏️</button>
                <button style={{...gBtn(),fontSize:10,padding:"3px 8px"}} onClick={()=>dupProduct(p)}>📋</button>
                <button style={{...gBtn(),fontSize:10,padding:"3px 8px",color:C.re}} onClick={()=>{if(window.confirm("I-delete ang "+p.name+"?"))delProduct(p.id);}}>🗑</button>
              </div>
            </div>
          ))}
        </div>
      ):(
        <Card><Tbl cols={[t.prod,t.cat,t.price,t.stock,""]} rows={filtered.map(p=>[
          <div><B>{p.name}</B><div style={{fontSize:10,color:C.d3,fontFamily:"monospace"}}>{p.sku}</div></div>,
          <Chip c="blue">{p.cat}</Chip>,
          <span style={{color:C.gr,fontWeight:700}}>{P(p.price)}</span>,
          <Chip c={p.stock<=p.min?"red":"green"}>{p.stock}</Chip>,
          <div style={{display:"flex",gap:4}}>
            <button style={{...gBtn(),padding:"3px 8px",fontSize:14}} onClick={()=>adjStock(p.id,-1)}>−</button>
            <button style={{...bSt(),padding:"3px 8px",fontSize:14}} onClick={()=>adjStock(p.id,+1)}>+</button>
            <button style={{...gBtn(),padding:"3px 8px",fontSize:11}} onClick={()=>setModal({type:"editProd",data:p})}>✏️</button>
            <button style={{...gBtn(),padding:"3px 8px",fontSize:11}} onClick={()=>dupProduct(p)}>📋</button>
          </div>
        ])}/></Card>
      )}
    </div>
  );
}

function CatsPage({t,cats,products,addCat,editCat,delCat,setModal,setTab}) {
  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10}}>
        {cats.map(c=>{
          const count=products.filter(p=>p.cat===c.name).length;
          return (
            <div key={c.id} style={{background:C.bg2,border:`1px solid ${C.b}`,borderRadius:10,padding:"14px",borderLeft:`4px solid ${c.color}`}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <div><div style={{fontSize:15,fontWeight:800,color:"#fff"}}>{c.name}</div><div style={{fontSize:11,color:C.d2,marginTop:2}}>{count} produkto</div></div>
                <div style={{width:14,height:14,borderRadius:"50%",background:c.color,marginTop:2}}/>
              </div>
              <div style={{display:"flex",gap:6}}>
                <button style={{...gBtn(),fontSize:11}} onClick={()=>setModal({type:"editCat",data:c})}>✏️ {t.edit}</button>
                <button style={{...gBtn(),fontSize:11,color:C.re}} onClick={()=>{if(count>0){alert("May produkto pa sa kategoryang ito.");}else if(window.confirm("I-delete?"))delCat(c.id);}}>🗑</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ReorderPage({t,lowStock,adjStock,setTab,addExpense,addProduct}) {
  const [restocked,   setRestocked]   = useState({});
  const [orderMode,   setOrderMode]   = useState({}); // {pid: "pack"|"tingi"}
  const [customQty,   setCustomQty]   = useState({});
  const [showAddCustom,setShowAddCustom] = useState(false);
  const [customItem,  setCustomItem]  = useState({name:"",qty:"",cost:"",unit:"piraso",addToInv:true});
  const [customDone,  setCustomDone]  = useState([]);

  const getMode   = (p) => orderMode[p.id] || "pack";
  const getPackNm = (p) => getPackLabel(p);
  const getTingiNm= (p) => p.unit || "piraso";

  const handleRestock = (p) => {
    const mode = getMode(p);
    const rawQty = +(customQty[p.id]||p.orderQty);
    if(!rawQty||rawQty<=0) return;

    // Convert to pieces depending on mode
    const piecesAdded = mode==="tingi" ? rawQty : rawQty * (p.unitsPerPack||1);
    const costPerPiece = p.unitsPerPack>0 ? +p.cost/+p.unitsPerPack : +p.cost;
    const totalCost = mode==="tingi"
      ? costPerPiece * rawQty
      : +p.cost * rawQty; // cost per pack × packs

    adjStock(p.id, piecesAdded);

    // Record as Stock Purchase (not expense)
    if(p.cost>0) {
      DB.addStockPurchase({
        date: new Date().toISOString().slice(0,10),
        product: p.name,
        qty: piecesAdded,
        costPerUnit: costPerPiece,
        totalCost: totalCost,
        note: mode==="tingi"
          ? "Restock "+rawQty+" "+getTingiNm(p)
          : "Restock "+rawQty+" "+getPackNm(p)+"(s) = "+piecesAdded+" "+getTingiNm(p)
      });
    }
    setRestocked(r=>({...r,[p.id]:true}));
  };

  const handleAddCustom = () => {
    if(!customItem.name||!customItem.cost) return alert("Lagyan ng pangalan at halaga.");
    const amt = +customItem.cost;
    const qty = +customItem.qty||1;
    addExpense({date:new Date().toISOString().slice(0,10),type:"Puhunan/Iba pa",amount:amt,note:customItem.name+" ("+qty+" "+customItem.unit+")"});
    if(customItem.addToInv) {
      addProduct({
        name:customItem.name,sku:customItem.name.slice(0,3).toUpperCase()+"-"+Date.now().toString(36).slice(-3),
        cat:"Iba pa",price:0,cost:amt/Math.max(1,qty),stock:qty,min:1,orderQty:qty,unit:customItem.unit,
        variants:[],unitsPerPack:0,pricePerUnit:0
      });
    }
    setCustomDone(d=>[...d,customItem.name+" ("+P(amt)+")"]);
    setCustomItem({name:"",qty:"",cost:"",unit:"piraso",addToInv:true});
    setShowAddCustom(false);
  };

  const active = lowStock.filter(p=>!restocked[p.id]);
  const done   = lowStock.filter(p=>restocked[p.id]);

  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>

      {/* Add custom item */}
      <div style={{background:C.bg2,border:"1px solid "+C.bl,borderRadius:10,overflow:"hidden"}}>
        <div style={{padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{fontSize:13,fontWeight:700,color:"#fff"}}>➕ Dagdag na Binibili</div>
            <div style={{fontSize:11,color:C.d2}}>Hindi pa nasa listahan (Gasul, Ice, etc.)</div>
          </div>
          <button style={{...bSt(C.bl,"#fff"),fontSize:12}} onClick={()=>setShowAddCustom(o=>!o)}>
            {showAddCustom?"✕ Isara":"+ Dagdag"}
          </button>
        </div>
        {showAddCustom&&(
          <div style={{padding:"12px 14px",borderTop:"1px solid "+C.b,display:"flex",flexDirection:"column",gap:10}}>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <div style={{gridColumn:"1/-1"}}>
                <label style={lbSt}>Pangalan *</label>
                <input style={iSt()} value={customItem.name} onChange={e=>setCustomItem(p=>({...p,name:e.target.value}))} placeholder="e.g. Gasul, Ice..."/>
              </div>
              <div><label style={lbSt}>Dami</label><input type="number" style={iSt()} value={customItem.qty} onChange={e=>setCustomItem(p=>({...p,qty:e.target.value}))} placeholder="1"/></div>
              <div><label style={lbSt}>Unit</label>
                <select style={iSt()} value={customItem.unit} onChange={e=>setCustomItem(p=>({...p,unit:e.target.value}))}>
                  {TINGI_UNITS.map(u=><option key={u.val} value={u.val}>{u.label}</option>)}
                </select>
              </div>
              <div style={{gridColumn:"1/-1"}}>
                <label style={lbSt}>Halaga / Gastos (₱) *</label>
                <input type="number" style={iSt()} value={customItem.cost} onChange={e=>setCustomItem(p=>({...p,cost:e.target.value}))} placeholder="e.g. 850"/>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10,background:C.bg3,borderRadius:8,padding:"10px 12px",cursor:"pointer"}} onClick={()=>setCustomItem(p=>({...p,addToInv:!p.addToInv}))}>
              <div style={{width:20,height:20,borderRadius:4,border:"2px solid "+(customItem.addToInv?C.gr:C.b2),background:customItem.addToInv?C.gr:"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {customItem.addToInv&&<span style={{color:"#000",fontSize:13,fontWeight:800}}>✓</span>}
              </div>
              <div><div style={{fontSize:12,fontWeight:700,color:"#fff"}}>Idagdag sa Inventory</div><div style={{fontSize:11,color:C.d2}}>Para maibenta sa Quick Sale</div></div>
            </div>
            <div style={{display:"flex",gap:8}}>
              <button style={{...gBtn(),flex:1}} onClick={()=>setShowAddCustom(false)}>Cancel</button>
              <button style={{...bSt(C.gr,"#000"),flex:2}} onClick={handleAddCustom}>✅ I-Record</button>
            </div>
          </div>
        )}
      </div>

      {customDone.length>0&&customDone.map((d,i)=>(
        <div key={i} style={{background:C.gd,border:"1px solid "+C.gr+"40",borderRadius:8,padding:"8px 12px",fontSize:12,color:C.gr}}>✅ {d}</div>
      ))}

      {/* Reorder list */}
      {active.length===0&&lowStock.length>0 ? (
        <div style={{background:C.gd,border:"1px solid "+C.gr,borderRadius:10,padding:"16px",textAlign:"center"}}>
          <div style={{fontSize:32,marginBottom:8}}>🎉</div>
          <div style={{fontSize:15,fontWeight:800,color:C.gr}}>Lahat ay na-restock na!</div>
        </div>
      ) : active.length===0 ? (
        <Card><div style={{padding:"40px",textAlign:"center",color:C.d2}}>✅ {t.allStocked}</div></Card>
      ) : (
        <>
          <div style={{background:C.ad,border:"1px solid "+C.am,borderRadius:8,padding:"10px 14px",display:"flex",justifyContent:"space-between"}}>
            <span style={{color:C.am,fontWeight:600}}>⚠️ {active.length} produkto kailangan ng restock</span>
          </div>
          {active.map(p=>{
            const sh   = Math.max(0,p.min-p.stock);
  

            const pri  = p.stock===0?"critical":sh>=p.min*0.7?"high":"medium";
            const mode = getMode(p);
            const hasTingiOpt = p.unitsPerPack>0;
            const packNm = getPackNm(p);
            const tingiNm= getTingiNm(p);
            const rawQty = +(customQty[p.id]||p.orderQty);
            const piecesWillAdd = mode==="tingi" ? rawQty : rawQty*(p.unitsPerPack||1);
            const costPerPiece  = p.unitsPerPack>0 ? p.cost/p.unitsPerPack : p.cost;
            const estCost = mode==="tingi" ? costPerPiece*rawQty : p.cost*rawQty;
            return (
              <div key={p.id} style={{background:C.bg2,border:"1px solid "+C.b,borderRadius:10,padding:"14px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                  <div>
                    <div style={{fontSize:14,fontWeight:800,color:"#fff"}}>{p.name}</div>
                    <div style={{fontSize:11,color:C.d3,fontFamily:"monospace"}}>{p.sku}</div>
                    <div style={{marginTop:4,display:"flex",gap:6}}>
                      <Chip c="red">Stock: {p.stock} {tingiNm}</Chip>
                      <Chip c={{critical:"red",high:"amber",medium:"blue"}[pri]}>{t[pri]||pri}</Chip>
                    </div>
                    {hasTingiOpt&&<div style={{fontSize:10,color:C.d2,marginTop:3}}>1 {packNm} = {p.unitsPerPack} {tingiNm} · Cost: {P(p.cost)}/{packNm}</div>}
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:11,color:C.d2}}>Kulang: <span style={{color:C.re,fontWeight:700}}>{sh} {tingiNm}</span></div>
                  </div>
                </div>

                {/* Order mode toggle */}
                {hasTingiOpt&&(
                  <div style={{display:"flex",gap:6,marginBottom:10}}>
                    <button onClick={()=>setOrderMode(m=>({...m,[p.id]:"pack"}))}
                      style={{flex:1,padding:"7px",borderRadius:8,border:"1px solid "+(mode==="pack"?C.bl:C.b2),
                        background:mode==="pack"?C.bd:"transparent",color:mode==="pack"?C.bl:C.d2,
                        fontSize:12,fontWeight:mode==="pack"?700:400,cursor:"pointer"}}>
                      📦 Order by {packNm}
                    </button>
                    <button onClick={()=>setOrderMode(m=>({...m,[p.id]:"tingi"}))}
                      style={{flex:1,padding:"7px",borderRadius:8,border:"1px solid "+(mode==="tingi"?C.am:C.b2),
                        background:mode==="tingi"?C.ad:"transparent",color:mode==="tingi"?C.am:C.d2,
                        fontSize:12,fontWeight:mode==="tingi"?700:400,cursor:"pointer"}}>
                      ✂️ Order by {tingiNm}
                    </button>
                  </div>
                )}

                {/* Qty input */}
                <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:6}}>
                  <div style={{fontSize:12,color:C.d2,flexShrink:0}}>Order:</div>
                  <input type="number" min="1"
                    value={customQty[p.id]!==undefined?customQty[p.id]:p.orderQty}
                    onChange={e=>setCustomQty(q=>({...q,[p.id]:e.target.value}))}
                    style={{...iSt(),flex:1,padding:"8px 10px",fontSize:14}}/>
                  <span style={{fontSize:12,color:C.d2,flexShrink:0}}>{mode==="pack"?packNm:tingiNm}</span>
                  <button onClick={()=>handleRestock(p)}
                    style={{...bSt(C.gr,"#000"),padding:"10px 14px",fontSize:13,fontWeight:800,flexShrink:0}}>
                    ✓ Na-stock
                  </button>
                </div>

                {/* Summary */}
                <div style={{background:C.bg3,borderRadius:6,padding:"7px 10px",fontSize:11,color:C.d2}}>
                  {mode==="pack"
                    ? <span>{rawQty} {packNm} × {p.unitsPerPack||1} {tingiNm} = <strong style={{color:"#fff"}}>{piecesWillAdd} {tingiNm}</strong> madadagdag · Est: <strong style={{color:C.am}}>{P(estCost)}</strong></span>
                    : <span>{rawQty} {tingiNm} madadagdag · Est: <strong style={{color:C.am}}>{P(estCost)}</strong></span>
                  }
                </div>
              </div>
            );
          })}
        </>
      )}

      {done.length>0&&(
        <div>
          <div style={{fontSize:12,color:C.d2,fontWeight:700,textTransform:"uppercase",marginBottom:8}}>✅ Na-restock na ({done.length}):</div>
          {done.map(p=>(
            <div key={p.id} style={{background:C.gd,border:"1px solid "+C.gr+"40",borderRadius:8,padding:"10px 14px",display:"flex",justifyContent:"space-between",marginBottom:6}}>
              <span style={{fontSize:13,fontWeight:600,color:"#fff"}}>{p.name}</span>
              <span style={{fontSize:12,color:C.gr}}>✓ Na-restock</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
function ExpPage({t,expenses,delExpense,setTab}) {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo,   setDateTo]   = useState("");
  const [activeTab,setActiveTab]= useState("expenses"); // expenses | stock

  // Filter real operating expenses (NOT stock purchases)
  const realExp = expenses.filter(e=>e.type!=="Purchased Capital");
  const stockPurchases = DB.getStockPurchases();

  // Apply date filter
  const filteredExp = realExp.filter(e=>{
    if(dateFrom && e.date<dateFrom) return false;
    if(dateTo   && e.date>dateTo)   return false;
    return true;
  });
  const filteredStock = stockPurchases.filter(sp=>{
    if(dateFrom && sp.date<dateFrom) return false;
    if(dateTo   && sp.date>dateTo)   return false;
    return true;
  });

  const total      = filteredExp.reduce((a,e)=>a+e.amount,0);
  const totalStock = filteredStock.reduce((a,s)=>a+s.totalCost,0);
  const byType     = filteredExp.reduce((acc,e)=>{acc[e.type]=(acc[e.type]||0)+e.amount;return acc;},{});

  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>

      {/* Date filter */}
      <div style={{display:"flex",gap:6,alignItems:"center",background:C.bg2,border:"1px solid "+(dateFrom?C.am:C.b),borderRadius:9,padding:"8px 12px"}}>
        <span style={{fontSize:11,color:dateFrom?C.am:C.d2,flexShrink:0,fontWeight:700}}>📅</span>
        <input type="date" style={{...iSt(),flex:1,padding:"5px 8px",fontSize:12}} value={dateFrom} onChange={e=>setDateFrom(e.target.value)}/>
        <span style={{color:C.d2,fontSize:11,flexShrink:0}}>–</span>
        <input type="date" style={{...iSt(),flex:1,padding:"5px 8px",fontSize:12}} value={dateTo} onChange={e=>setDateTo(e.target.value)}/>
        {(dateFrom||dateTo)&&<button style={{...gBtn(),color:C.re,padding:"3px 8px",fontSize:11}} onClick={()=>{setDateFrom("");setDateTo("");}}>✕</button>}
      </div>

      {/* Tab switcher */}
      <div style={{display:"flex",background:C.bg2,border:"1px solid "+C.b,borderRadius:10,overflow:"hidden"}}>
        <button onClick={()=>setActiveTab("expenses")}
          style={{flex:1,padding:"10px",background:activeTab==="expenses"?C.bg3:"transparent",
            border:"none",borderBottom:activeTab==="expenses"?"2px solid "+C.re:"2px solid transparent",
            color:activeTab==="expenses"?"#fff":C.d2,fontSize:13,fontWeight:activeTab==="expenses"?700:400,cursor:"pointer"}}>
          🧾 Gastos ({filteredExp.length})
        </button>
        <button onClick={()=>setActiveTab("stock")}
          style={{flex:1,padding:"10px",background:activeTab==="stock"?C.bg3:"transparent",
            border:"none",borderBottom:activeTab==="stock"?"2px solid "+C.bl:"2px solid transparent",
            color:activeTab==="stock"?"#fff":C.d2,fontSize:13,fontWeight:activeTab==="stock"?700:400,cursor:"pointer"}}>
          📦 Stock Purchases ({filteredStock.length})
        </button>
      </div>

      {activeTab==="expenses"&&(
        <>
          <Grid2>
            <StatCard v={P(total)} label="Total Gastos" sub={filteredExp.length+" items"+(dateFrom?" (filtered)":"")} color={C.re} icon="🧾"/>
            <div style={{background:C.bg2,border:"1px solid "+C.b,borderRadius:10,padding:"12px"}}>
              <div style={{fontSize:10,fontWeight:700,color:C.d2,textTransform:"uppercase",marginBottom:8}}>By Type</div>
              {Object.entries(byType).slice(0,5).map(([k,v])=>(
                <div key={k} style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:12}}>
                  <span style={{color:C.d2}}>{k}</span>
                  <span style={{color:C.re,fontWeight:700}}>{P(v)}</span>
                </div>
              ))}
              {Object.keys(byType).length===0&&<div style={{color:C.d3,fontSize:12}}>Walang gastos pa</div>}
            </div>
          </Grid2>
          <Card title="🧾 Operating Expenses">
            {filteredExp.length===0
              ? <div style={{padding:"24px",textAlign:"center",color:C.d2}}>Walang gastos sa period na ito.</div>
              : <Tbl cols={[t.date,"Uri",t.amt,""]} rows={[...filteredExp].reverse().map(e=>[
                <span style={{fontSize:11,background:C.bg3,padding:"2px 6px",borderRadius:4,color:C.d2}}>{e.date}</span>,
                <B>{e.type}</B>,
                <span style={{color:C.re,fontWeight:700}}>{P(e.amount)}</span>,
                <button style={{...gBtn(),color:C.re,fontSize:11}} onClick={()=>delExpense(e.id)}>🗑</button>
              ])}/>}
          </Card>
        </>
      )}

      {activeTab==="stock"&&(
        <>
          <div style={{background:C.bd,border:"1px solid "+C.bl,borderRadius:10,padding:"12px 14px"}}>
            <div style={{fontSize:12,color:C.d2,marginBottom:4}}>📦 Total Stock Purchased</div>
            <div style={{fontSize:22,fontWeight:900,color:C.am}}>{P(totalStock)}</div>
            <div style={{fontSize:11,color:C.d2,marginTop:2}}>{filteredStock.length} purchases{dateFrom?" (filtered)":""}</div>
            <div style={{fontSize:11,color:C.d3,marginTop:6,lineHeight:1.6}}>
              💡 Stock purchases are NOT counted as operating expenses. They become COGS only when items are sold.
            </div>
          </div>
          <Card title="📦 Stock Purchase History">
            {filteredStock.length===0
              ? <div style={{padding:"24px",textAlign:"center",color:C.d2}}>Walang stock purchase pa.</div>
              : <div>
                {[...filteredStock].reverse().map((sp,i)=>(
                  <div key={sp.id||i} style={{padding:"10px 14px",borderBottom:i<filteredStock.length-1?"1px solid "+C.b:"none"}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                      <span style={{fontSize:13,fontWeight:700,color:"#fff"}}>{sp.product}</span>
                      <span style={{fontSize:14,fontWeight:800,color:C.am}}>{P(sp.totalCost)}</span>
                    </div>
                    <div style={{fontSize:11,color:C.d2}}>{sp.date} · {sp.qty} {sp.note?("pcs · "+sp.note):"pcs"}</div>
                    <div style={{fontSize:11,color:C.d3}}>@ {P(sp.costPerUnit)}/unit</div>
                  </div>
                ))}
              </div>}
          </Card>
        </>
      )}
    </div>
  );
}

function ReportPage({t,expenses,products,setTab}) {
  const [period,setPeriod]=useState("daily");
  const [customFrom,setCustomFrom]=useState("");
  const [customTo,  setCustomTo]  =useState("");
  const [sending,setSending]=useState(false);
  const [sendStatus,setSendStatus]=useState(""); // ""|"ok"|"error"|"nourl"
  const [showSetup,setShowSetup]=useState(false);
  const [webhookUrl,setWebhookUrl]=useState(()=>DB.get("bb4_gsheet_url",""));
  const [storeName,setStoreName]=useState(()=>DB.get("bb4_store_name","My Store"));

  const from = customFrom || (period==="daily"?td():period==="weekly"?wk():mo());
  const toDate = customTo || new Date().toISOString().slice(0,10);
  const label=period==="daily"?t.today:period==="weekly"?t.thisWeek:t.thisMonth;
  const allSales=DB.getAllSales();
  const fs = allSales.filter(s=>s.date>=from&&s.date<=toDate);
  // Real operating expenses ONLY (no stock purchases)
  const fe = expenses.filter(e=>e.date>=from&&e.date<=toDate&&e.type!=="Purchased Capital");
  // Correct Total Sales = selling_price × qty
  const income = fs.filter(s=>s.paid).reduce((a,s)=>
    a+(s.items||[]).reduce((b,it)=>b+(+it.price * +it.qty),0),0);
  // Correct COGS = cost_per_unit × qty_sold
  const cogs = fs.filter(s=>s.paid).reduce((a,s)=>
    a+(s.items||[]).reduce((b,it)=>{
      const prod=products.find(p=>p.id===it.pid||p.id===Number(it.pid));
      if(!prod||!+prod.cost) return b;
      const ppu=+prod.pricePerUnit, upp=+prod.unitsPerPack;
      const soldAsTingi = ppu>0&&upp>0&&Math.abs(+it.price-ppu)<0.01;
      const cpu = soldAsTingi ? +prod.cost/upp : +prod.cost;
      return b+(cpu*+it.qty);
    },0),0);
  const grossProfit = income - cogs;
  const exp = fe.reduce((a,e)=>a+e.amount,0);
  const profit = grossProfit - exp; // Net Profit
  const pm={};
  fs.forEach(s=>s.items&&s.items.forEach(it=>{if(!pm[it.pid])pm[it.pid]={qty:0,rev:0};pm[it.pid].qty+=it.qty;pm[it.pid].rev+=it.price*it.qty;}));
  const top=Object.entries(pm).map(([id,v])=>({...v,p:products.find(pr=>pr.id===id||pr.id===Number(id))})).filter(x=>x.p).sort((a,b)=>b.rev-a.rev).slice(0,5);

  const saveSettings=()=>{
    DB.set("bb4_gsheet_url",webhookUrl);
    DB.set("bb4_store_name",storeName);
    setShowSetup(false);
    setSendStatus("saved");
    setTimeout(()=>setSendStatus(""),3000);
  };

  const sendReport=async()=>{
    const url=DB.get("bb4_gsheet_url","");
    if(!url){setShowSetup(true);return;}
    setSending(true);setSendStatus("");
    try{
      const payload={
        storeName: DB.get("bb4_store_name","My Store"),
        period: label,
        sentAt: new Date().toLocaleString("en-PH"),
        sales: allSales.filter(s=>s.date>=from),
        products: products,
        expenses: fe,
        summary:{
          totalSalesPaid: income,
          totalUnpaid: fs.filter(s=>!s.paid).reduce((a,s)=>a+s.total,0),
          totalExpenses: exp,
          netProfit: profit,
          totalTransactions: fs.length,
          lowStockCount: products.filter(p=>p.stock<=p.min).length
        }
      };
      await fetch(url,{method:"POST",body:JSON.stringify(payload),headers:{"Content-Type":"application/json"},mode:"no-cors"});
      setSendStatus("ok");
    }catch(err){
      setSendStatus("error");
    }finally{
      setSending(false);
      setTimeout(()=>setSendStatus(""),5000);
    }
  };

  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>

      {/* ── Google Sheets Setup Banner ── */}
      {!DB.get("bb4_gsheet_url","") && (
        <div style={{background:"#0a1628",border:`1px solid ${C.bl}`,borderRadius:10,padding:"12px 14px",display:"flex",gap:10,alignItems:"center"}}>
          <span style={{fontSize:22}}>📊</span>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:C.bl}}>I-setup ang Google Sheets</div>
            <div style={{fontSize:11,color:C.d2,marginTop:2}}>I-send ang reports sa inyong Google Sheets para makita ng owner</div>
          </div>
          <button style={{...bSt(C.bl,"#fff"),fontSize:11,padding:"6px 12px"}} onClick={()=>setShowSetup(true)}>Setup →</button>
        </div>
      )}

      {/* ── Status messages ── */}
      {sendStatus==="ok"    && <div style={{background:"#071f17",border:`1px solid ${C.gr}`,borderRadius:8,padding:"10px 14px",color:C.gr,fontWeight:700,fontSize:13}}>✅ Na-send na sa Google Sheets! Tingnan mo na ang spreadsheet.</div>}
      {sendStatus==="error" && <div style={{background:C.rd,border:`1px solid ${C.re}`,borderRadius:8,padding:"10px 14px",color:C.re,fontWeight:700,fontSize:13}}>❌ Hindi na-send. I-check ang webhook URL sa Settings.</div>}
      {sendStatus==="saved" && <div style={{background:"#071f17",border:`1px solid ${C.gr}`,borderRadius:8,padding:"10px 14px",color:C.gr,fontWeight:700,fontSize:13}}>✅ Na-save ang settings!</div>}

      {/* ── Setup Modal ── */}
      {showSetup && (
        <div style={{background:C.bg2,border:`1px solid ${C.bl}`,borderRadius:12,padding:"16px"}}>
          <div style={{fontSize:14,fontWeight:800,color:"#fff",marginBottom:4}}>📊 Google Sheets Setup</div>
          <div style={{fontSize:11,color:C.d2,marginBottom:14,lineHeight:1.7}}>
            1. Buksan ang Google Sheets<br/>
            2. Extensions → Apps Script<br/>
            3. I-paste ang script → I-deploy as Web App<br/>
            4. I-copy ang Web App URL → I-paste dito
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <div>
              <label style={lbSt}>Store Name</label>
              <input style={iSt()} value={storeName} onChange={e=>setStoreName(e.target.value)} placeholder="e.g. Aling Nena Store"/>
            </div>
            <div>
              <label style={lbSt}>Google Sheets Webhook URL</label>
              <input style={iSt()} value={webhookUrl} onChange={e=>setWebhookUrl(e.target.value)} placeholder="https://script.google.com/macros/s/..."/>
            </div>
            <div style={{display:"flex",gap:8}}>
              <button style={{...gBtn(),flex:1}} onClick={()=>setShowSetup(false)}>Kanselahin</button>
              <button style={{...bSt(),flex:2}} onClick={saveSettings}>💾 I-save</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Period selector + Send button ── */}
      <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
        {["daily","weekly","monthly"].map(v=><button key={v} style={period===v?bSt():gBtn()} onClick={()=>setPeriod(v)}>{v==="daily"?t.daily:v==="weekly"?t.weekly:t.monthly}</button>)}
        <span style={{fontSize:11,color:C.d2,fontWeight:600}}>{label}</span>
      </div>
      {/* Custom date range */}
      <div style={{display:"flex",gap:8,alignItems:"center",background:C.bg2,border:"1px solid "+C.b,borderRadius:8,padding:"8px 12px"}}>
        <span style={{fontSize:11,color:C.d2,flexShrink:0}}>📅 Custom:</span>
        <input type="date" style={{...iSt(),flex:1,padding:"5px 8px",fontSize:12}} value={customFrom} onChange={e=>setCustomFrom(e.target.value)}/>
        <span style={{color:C.d2,fontSize:12}}>–</span>
        <input type="date" style={{...iSt(),flex:1,padding:"5px 8px",fontSize:12}} value={customTo} onChange={e=>setCustomTo(e.target.value)}/>
        {(customFrom||customTo)&&<button style={{...gBtn(),fontSize:11,padding:"4px 8px",color:C.re}} onClick={()=>{setCustomFrom("");setCustomTo("");}}>✕</button>}
      </div>

      {/* ── Correct Stats ── */}
      <Grid2>
        <StatCard v={P(income)}      label="Total Sales"   sub={fs.filter(s=>s.paid).length+" txn"} color={C.cy}  icon="💰"/>
        <StatCard v={P(cogs)}        label="COGS"          sub="Cost of goods sold"                  color={C.re}  icon="📦"/>
        <StatCard v={P(grossProfit)} label="Gross Profit"  sub="Sales − COGS"                        color={C.am}  icon="📊"/>
        <StatCard v={P(exp)}         label="Expenses"      sub={fe.length+" operating items"}         color={C.re}  icon="🧾"/>
      </Grid2>
      {/* Net Profit highlight box */}
      <div style={{background:profit>=0?"linear-gradient(135deg,#071f17,#071428)":"linear-gradient(135deg,#2a0a0a,#1a0a0a)",
        border:"2px solid "+(profit>=0?C.gr:C.re),borderRadius:12,padding:"14px 16px",
        display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:12,fontWeight:800,color:profit>=0?C.gr:C.re}}>📈 NET PROFIT</div>
          <div style={{fontSize:11,color:C.d2,marginTop:3}}>Gross Profit ({P(grossProfit)}) − Expenses ({P(exp)})</div>
        </div>
        <div style={{fontSize:28,fontWeight:900,color:profit>=0?C.gr:C.re}}>{P(profit)}</div>
      </div>

      {/* ── SEND TO GOOGLE SHEETS BUTTON ── */}
      <button onClick={sendReport} disabled={sending}
        style={{...bSt("#0f9d58","#fff"),width:"100%",justifyContent:"center",padding:"14px",fontSize:15,fontWeight:800,opacity:sending?0.6:1,border:"none",borderRadius:10}}>
        {sending ? "📤 Nagpapadala..." : "📊 I-SEND SA GOOGLE SHEETS"}
      </button>
      {DB.get("bb4_store_name","") && <div style={{textAlign:"center",fontSize:11,color:C.d2,marginTop:-6}}>Store: <strong style={{color:"#fff"}}>{DB.get("bb4_store_name","")}</strong> · Period: {label}</div>}

      {/* ── Profit Summary ── */}
      <Card title="📊 Profit Breakdown">
        <div style={{padding:"14px"}}>
          {[
            ["💰 Total Sales",     P(income),      C.cy],
            ["📦 COGS",           "−"+P(cogs),     C.re],
            ["📊 Gross Profit",    P(grossProfit),  C.am],
            ["🧾 Expenses",       "−"+P(exp),      C.re],
          ].map(([l,v,c],i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.b}`}}>
              <span style={{color:C.d2,fontSize:13}}>{l}</span>
              <span style={{color:c,fontWeight:700}}>{v}</span>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"space-between",paddingTop:10}}>
            <span style={{fontWeight:700,fontSize:14,color:"#fff"}}>📈 Net Profit</span>
            <span style={{fontWeight:800,fontSize:20,color:profit>=0?C.am:C.re}}>{P(profit)}</span>
          </div>
        </div>
      </Card>

      {top.length>0 && <Card title={"🏆 "+t.topProds}><Tbl cols={[t.prod,"Qty","Revenue"]} rows={top.map((x,i)=>[<B>{["🥇","🥈","🥉","4.","5."][i]} {x.p.name}</B>,<span style={{color:C.bl,fontWeight:600}}>{x.qty}</span>,<span style={{color:C.am,fontWeight:700}}>{P(x.rev)}</span>])}/></Card>}

      {/* ── Settings shortcut ── */}
      <button onClick={()=>setShowSetup(true)} style={{...gBtn(),width:"100%",justifyContent:"center",fontSize:11}}>
        ⚙️ I-edit ang Google Sheets Settings
      </button>
    </div>
  );
}

function BackupPage({t,restoreData}) {
  const [manList,setManList]=useState(()=>DB.get("backups",[]));
  const [autoList,setAutoList]=useState(()=>DB.get("auto_bk",[]));
  const [activeTab,setATab]=useState("auto");
  const [label,setLabel]=useState("");
  const [status,setStatus]=useState("");
  const [confirm,setConfirm]=useState(null);
  const fileRef=useRef();
  const refresh=()=>{setManList(DB.get("backups",[]));setAutoList(DB.get("auto_bk",[]));};
  const ok=msg=>{setStatus("✅ "+msg);setTimeout(()=>setStatus(""),4000);};
  const fail=msg=>{setStatus("❌ "+msg);setTimeout(()=>setStatus(""),4000);};
  const doManual=()=>{DB.saveBackup(label.trim()||undefined);setLabel("");refresh();ok("Backup saved!");};
  const doUpload=async e=>{try{const txt=await e.target.files[0].text();const p=JSON.parse(txt);setConfirm({data:p.data||p,label:p.label||e.target.files[0].name});}catch{fail("Invalid file.");}e.target.value="";};
  const doRestore=()=>{restoreData(confirm.data);setConfirm(null);ok("Data restored! I-refresh kung kailangan.");};
  return (
    <div style={colStyle}>
      {status && <AlertBar c={status.startsWith("✅")?"green":"red"}>{status}</AlertBar>}
      <Grid2>
        <StatCard v={DB.sizeKB()+" KB"} label="Storage" sub="" color={C.bl} icon="💿"/>
        <StatCard v={autoList.length} label="Auto Backups" sub="48 max" color={C.gr} icon="🤖"/>
        <StatCard v={manList.length} label="Manual" sub="30 max" color={C.pu} icon="👤"/>
        <StatCard v={DB.get("last_ab",null)?new Date(DB.get("last_ab")).toLocaleTimeString("en-PH"):"None"} label="Last Auto" sub="" color={C.am} icon="⏱️"/>
      </Grid2>
      <Card title="💾 Gumawa ng Backup">
        <div style={{padding:"12px 14px",display:"flex",flexDirection:"column",gap:8}}>
          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
            <input style={{...iSt(),flex:1,minWidth:140}} placeholder="Label (optional)" value={label} onChange={e=>setLabel(e.target.value)}/>
            <button style={bSt()} onClick={doManual}>💾 {t.bkNow}</button>
          </div>
          <button style={gBtn()} onClick={()=>fileRef.current&&fileRef.current.click()}>📂 {t.restoreFile}</button>
          <input ref={fileRef} type="file" accept=".json" style={{display:"none"}} onChange={doUpload}/>
        </div>
      </Card>
      <Card>
        <div style={{display:"flex",borderBottom:`1px solid ${C.b}`}}>
          {[{id:"auto",l:`🤖 Auto (${autoList.length})`},{id:"man",l:`👤 Manual (${manList.length})`}].map(tb=>(
            <button key={tb.id} onClick={()=>setATab(tb.id)} style={{flex:1,padding:"10px",background:activeTab===tb.id?C.bg3:"transparent",border:"none",borderBottom:activeTab===tb.id?`2px solid ${C.bl}`:"2px solid transparent",color:activeTab===tb.id?"#fff":C.d2,fontSize:12,fontWeight:activeTab===tb.id?700:400,cursor:"pointer"}}>{tb.l}</button>
          ))}
        </div>
        {(activeTab==="auto"?autoList:manList).slice(0,8).map((b,i,arr)=>(
          <div key={b.id} style={{padding:"10px 14px",borderBottom:i<arr.length-1?`1px solid ${C.b}`:"none",display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
            <div style={{flex:1,minWidth:150}}><div style={{fontSize:12,fontWeight:700,color:"#fff"}}>{b.label||new Date(b.ts).toLocaleString("en-PH")}</div><div style={{fontSize:10,color:C.d3}}>{b.kb} KB</div></div>
            <div style={{display:"flex",gap:5}}>
              <button style={{...gBtn(),fontSize:11}} onClick={()=>DB.download(b)}>⬇️</button>
              <button style={{...gBtn(),fontSize:11,color:C.am}} onClick={()=>setConfirm({data:b.data,label:b.label||"Auto backup"})}>🔄</button>
            </div>
          </div>
        ))}
        {(activeTab==="auto"?autoList:manList).length===0 && <Empty>Wala pang backup dito.</Empty>}
      </Card>
      {confirm && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:16}}>
          <div style={{background:C.bg2,border:`1px solid ${C.re}`,borderRadius:14,padding:"24px 20px",maxWidth:380,width:"100%",textAlign:"center"}}>
            <div style={{fontSize:40,marginBottom:10}}>⚠️</div>
            <div style={{fontSize:15,fontWeight:800,color:"#fff",marginBottom:8}}>I-Restore ang Data?</div>
            <div style={{background:C.bg3,borderRadius:8,padding:"8px 12px",color:C.am,fontWeight:700,fontSize:13,marginBottom:16}}>{confirm.label}</div>
            <div style={{display:"flex",gap:8}}>
              <button style={{...gBtn(),flex:1}} onClick={()=>setConfirm(null)}>{t.cancel}</button>
              <button style={{...bSt(C.rd,C.re),border:`1px solid ${C.re}`,flex:1}} onClick={doRestore}>✅ Restore</button>
            </div>
          </div>
        </div>
      )}
    {/* DANGER ZONE */}
      <ClearDataSection restoreData={restoreData}/>
    </div>
  );
}

function ClearDataSection({restoreData}) {
  const STEPS = ["confirm","pin","final"];
  const [step, setStep] = React.useState(0); // 0=button, 1=confirm, 2=pin, 3=final confirm
  const [pin,  setPin]  = React.useState("");
  const [err,  setErr]  = React.useState("");
  const [done, setDone] = React.useState(false);

  const doFinal=()=>{
    if(pin!=="0000"&&pin!=="1234"&&pin!=="5678"){
      setErr("Mali ang PIN. Subukan ulit.");setPin("");return;
    }
    DB.saveBackup("⚠️ Bago I-Clear — "+new Date().toLocaleString("en-PH"));
    Object.keys(localStorage).filter(k=>k.startsWith("bb4_")).forEach(k=>localStorage.removeItem(k));
    setDone(true);
    setTimeout(()=>window.location.reload(),2000);
  };

  if(done) return (
    <div style={{background:C.gd,border:"1px solid "+C.gr,borderRadius:10,padding:"20px",textAlign:"center"}}>
      <div style={{fontSize:32,marginBottom:8}}>✅</div>
      <div style={{color:C.gr,fontWeight:800,fontSize:15}}>Na-clear na ang lahat ng data!</div>
      <div style={{color:C.d2,fontSize:12,marginTop:4}}>Nag-rere-load ang app...</div>
    </div>
  );

  return (
    <div style={{background:C.rd,border:"2px solid "+C.re,borderRadius:12,padding:"16px"}}>
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
        <span style={{fontSize:22}}>🗑️</span>
        <div>
          <div style={{fontSize:14,fontWeight:800,color:C.re}}>I-Clear ang Lahat ng Data</div>
          <div style={{fontSize:11,color:C.d2,marginTop:2}}>Mabubura lahat ng produkto, benta, at gastos. Hindi na mababawi!</div>
        </div>
      </div>

      {step===0&&(
        <button onClick={()=>setStep(1)}
          style={{...bSt(C.rd,C.re),border:"1px solid "+C.re,width:"100%",justifyContent:"center",padding:"10px",fontWeight:700}}>
          🗑️ I-Clear ang Lahat ng Data
        </button>
      )}

      {step===1&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{background:"#3a0000",borderRadius:8,padding:"12px",fontSize:13,color:"#fff",lineHeight:1.7}}>
            <strong style={{color:C.re}}>⚠️ Sigurado ka ba?</strong><br/>
            Kapag na-clear ang data:<br/>
            • Mabubura ang lahat ng produkto<br/>
            • Mabubura ang lahat ng benta at utang<br/>
            • Mabubura ang lahat ng gastos<br/>
            <strong style={{color:C.am}}>Awtomatikong mag-ba-backup bago burahin.</strong>
          </div>
          <div style={{display:"flex",gap:8}}>
            <button style={{...gBtn(),flex:1}} onClick={()=>setStep(0)}>← Bumalik</button>
            <button style={{...bSt(C.re,"#fff"),flex:1,justifyContent:"center"}} onClick={()=>setStep(2)}>
              Oo, i-clear ko ito →
            </button>
          </div>
        </div>
      )}

      {step===2&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{fontSize:12,color:"#fff",fontWeight:600}}>Huling hakbang — i-type ang iyong PIN:</div>
          <input type="password" maxLength={6} autoFocus
            placeholder="I-type ang PIN mo dito"
            style={{...iSt(),fontSize:22,letterSpacing:10,textAlign:"center",border:"2px solid "+C.re}}
            value={pin} onChange={e=>{setPin(e.target.value);setErr("");}}
            onKeyDown={e=>e.key==="Enter"&&doFinal()}/>
          {err&&<div style={{color:C.re,fontSize:12,fontWeight:700}}>{err}</div>}
          <div style={{fontSize:10,color:C.d3,textAlign:"center"}}>Owner PIN: 0000 · Admin: 1234 · Dev: 5678</div>
          <div style={{display:"flex",gap:8}}>
            <button style={{...gBtn(),flex:1}} onClick={()=>{setStep(1);setPin("");setErr("");}}>← Bumalik</button>
            <button style={{...bSt(C.re,"#fff"),flex:1,justifyContent:"center",fontWeight:800}} onClick={doFinal}>
              🗑️ I-Clear Lahat
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

  

// ═══════════════════════════════════════════════ MAIN SHELL
// ── Daily Summary ──────────────────────────────────
function DailySummary({sales,expenses}) {
  const today=new Date().toISOString().slice(0,10);
  const ts=sales.filter(s=>s.date===today);
  const rev=ts.filter(s=>s.paid).reduce((a,s)=>a+s.total,0);
  const exp=expenses.filter(e=>e.date===today).reduce((a,e)=>a+e.amount,0);
  const profit=rev-exp;
  const hr=new Date().getHours();
  const greeting=hr<12?"Magandang umaga":hr<17?"Magandang tanghali":"Magandang gabi";
  if(ts.length===0) return null;
  return (
    <div style={{background:"linear-gradient(135deg,#071f17,#071428)",border:"1px solid "+C.gr+"30",
      borderRadius:12,padding:"14px 16px"}}>
      <div style={{fontSize:11,color:C.d2,marginBottom:6}}>{greeting}! Araw natin ngayon:</div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:26,fontWeight:900,color:C.am,letterSpacing:"-0.5px"}}>{P(rev)}</div>
          <div style={{fontSize:11,color:C.d2,marginTop:2}}>{ts.length} benta ngayon</div>
        </div>
        <div style={{textAlign:"right"}}>
          <div style={{fontSize:18,fontWeight:700,color:profit>=0?C.gr:C.re}}>{P(profit)}</div>
          <div style={{fontSize:11,color:C.d2}}>kita ngayon</div>
        </div>
      </div>
    </div>
  );
}

// ── About Page ──────────────────────────────────────
function AboutPage({setShowOnboard,setTab}) {
  return (
    <div style={colStyle}>
      <BackBtn setTab={setTab}/>
      <div style={{background:"linear-gradient(135deg,#071f17,#071428)",border:"1px solid "+C.gr+"40",
        borderRadius:14,padding:"24px 20px",textAlign:"center"}}>
        <div style={{fontSize:52,marginBottom:10}}>🏪</div>
        <div style={{fontSize:22,fontWeight:900,color:"#fff",letterSpacing:"-0.5px"}}>Bantay Benta</div>
        <div style={{fontSize:12,color:C.d2,marginTop:4}}>Sari-Sari Store Manager v4 · Para sa mga Pilipinong negosyante</div>
      </div>
      <Card title="✅ Mga Features">
        <div style={{padding:"12px 14px",display:"flex",flexDirection:"column",gap:10}}>
          {[["⚡","3-Tap Quick Sale","Mabilis na pagtala ng benta"],
            ["✂️","Tingi System","Per stick, per sachet, per kilo"],
            ["🏷️","Variants","Marlboro Red/Blue/Menthol, etc."],
            ["📋","Utang Tracker","Partial payment, item details"],
            ["📊","Reports","Daily/Weekly/Monthly + custom dates"],
            ["💾","Auto-Backup","Awtomatikong nag-ba-backup"],
            ["📈","Profit Tracking","Buo at tingi profit computation"],
            ["🔄","Reorder Alerts","Kapag mababa na ang stock"],
          ].map(([icon,title,desc],i)=>(
            <div key={i} style={{display:"flex",gap:10,alignItems:"center"}}>
              <span style={{fontSize:20,flexShrink:0}}>{icon}</span>
              <div><div style={{fontSize:13,fontWeight:700,color:"#fff"}}>{title}</div>
              <div style={{fontSize:11,color:C.d2}}>{desc}</div></div>
            </div>
          ))}
        </div>
      </Card>
      <Card title="🔒 Privacy at Data">
        <div style={{padding:"12px 14px",fontSize:12,color:C.d2,lineHeight:1.8}}>
          <div>✅ <strong style={{color:"#fff"}}>Offline-first</strong> — Naka-save sa inyong phone. Hindi kinukuha ang data.</div>
          <div>✅ <strong style={{color:"#fff"}}>Walang account</strong> — Hindi kailangan ng email o sign-up.</div>
          <div>✅ <strong style={{color:"#fff"}}>Libre</strong> — Walang bayad.</div>
        </div>
      </Card>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        <button onClick={()=>{localStorage.removeItem("bb4_onboarded");setShowOnboard(true);}}
          style={{...bSt(C.bl,"#fff"),width:"100%",justifyContent:"center",padding:"12px",fontSize:13}}>
          📖 Pakita ulit ang Tutorial
        </button>
        <button onClick={()=>setTab("backup")}
          style={{...gBtn(),width:"100%",justifyContent:"center",color:C.re}}>
          🗑️ I-Clear ang Lahat ng Data
        </button>
      </div>
    </div>
  );
}

function Shell({t,lang,setLang,user,setUser,saved,products,setProducts,expenses,setExpenses,cats,setCats,restoreData}) {
  const [tab,       setTab]       = useState("dashboard");
  const [drawer,    setDrawer]    = useState(false);
  const [modal,     setModal]     = useState(null);
  const [showOnboard,setShowOnboard] = useState(()=>!localStorage.getItem("bb4_onboarded"));
  const isAdmin=user.role==="admin"||user.role==="developer";
  const [salesPage,setSalesPage]=useState(0);
  const [salesData,setSalesData]=useState(()=>DB.getSalesPage(0));
  const refreshSales=useCallback((page=0)=>{setSalesPage(page);setSalesData(DB.getSalesPage(page));},[]);
  const lowStock=useMemo(()=>products.filter(p=>p.stock<=p.min),[products]);
  const unpaidAll=useMemo(()=>DB.getAllSales().filter(s=>!s.paid),[salesData]);
  const unpaidAmt=useMemo(()=>unpaidAll.reduce((a,s)=>a+s.total,0),[unpaidAll]);
  const toast = useToast();
  const addSale=s=>{
    const ns={...s,id:uid()};
    DB.addSale(ns);
    s.items.forEach(it=>setProducts(p=>p.map(pr=>{
      if(pr.id!==it.pid&&pr.id!==Number(it.pid)) return pr;
      const deduct=it.piecesQty||it.qty;
      return {...pr,stock:Math.max(0,pr.stock-deduct)};
    })));
    refreshSales(0);
  };
  const markPaid=id=>{
    DB.updateSale(id,{paid:true});
    refreshSales(salesPage);
    toast&&toast("Bayad na! Na-update ang record.","success");
  };
  const togglePaid=(id,paid)=>{DB.toggleSalePaid(id,paid);refreshSales(salesPage);};
  const addPartialPayment=(id,amt)=>{DB.addPartialPayment(id,amt);refreshSales(salesPage);};
  const addProduct=pr=>{
    setProducts(p=>[...p,{...pr,id:uid()}]);
    toast&&toast(pr.name+" — naidagdag na!","success");
  };
  const dupProduct=pr=>setProducts(p=>[...p,{...pr,id:uid(),name:pr.name+" (Copy)",sku:pr.sku+"-C"}]);
  const editProduct=pr=>setProducts(p=>p.map(x=>x.id===pr.id?pr:x));
  const delProduct=id=>setProducts(p=>p.filter(x=>x.id!==id));
  const adjStock=(id,d)=>setProducts(p=>p.map(pr=>pr.id===id?{...pr,stock:Math.max(0,pr.stock+d)}:pr));
  const addExpense=e=>setExpenses(p=>[...p,{...e,id:uid()}]);
  const delExpense=id=>setExpenses(p=>p.filter(e=>e.id!==id));
  const addCat=c=>setCats(p=>[...p,{...c,id:uid()}]);
  const editCat=c=>setCats(p=>p.map(x=>x.id===c.id?c:x));
  const delCat=id=>setCats(p=>p.filter(x=>x.id!==id));
  const ownerNav=[
    {id:"dashboard",icon:"🏠",label:t.dash},
    {id:"quicksale",icon:"⚡",label:t.quickSale,highlight:true},
    {id:"sales",    icon:"💰",label:t.sales},
    {id:"payments", icon:"📋",label:t.pay,badge:unpaidAll.length},
    {id:"inventory",icon:"📦",label:t.inv,pulse:products.length===0},
    {id:"categories",icon:"🏷️",label:t.cats},
    {id:"reorder",  icon:"🔄",label:t.reorder,badge:lowStock.length},
    {id:"expenses", icon:"🧾",label:t.exp},
    {id:"reports",  icon:"📊",label:t.rep},
    {id:"backup",   icon:"💾", label:t.bk},
    {id:"about",    icon:"ℹ️",  label:"Tungkol"},
  ];
  const adminNav=isAdmin?[{id:"adminHome",icon:"🛡️",label:t.adm},{id:"bugs",icon:"🐛",label:t.bugs}]:[];
  const nav=[...ownerNav,...adminNav];
  const ctx={t,lang,user,products,expenses,cats,salesData,salesPage,lowStock,unpaidAll,unpaidAmt,refreshSales,addSale,markPaid,togglePaid,addPartialPayment,addProduct,dupProduct,editProduct,delProduct,adjStock,addExpense,delExpense,addCat,editCat,delCat,restoreData,setModal,setTab};
  return (
    <div style={{display:"flex",minHeight:"100vh",background:C.bg0,color:C.tx}}>
      {showOnboard&&<OnboardingModal
        onDone={()=>setShowOnboard(false)}
        setTab={(tabId)=>{setTab(tabId);setDrawer(false);}}/>}
      {drawer && <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.78)",zIndex:40}} onClick={()=>setDrawer(false)}/>}
      <aside className="tk-sb" style={{width:220,background:C.bg1,borderRight:`1px solid ${C.b}`,display:"flex",flexDirection:"column",position:"fixed",top:0,left:0,height:"100vh",zIndex:50,transform:drawer?"translateX(0)":"translateX(-100%)",transition:"transform 0.22s ease"}}>
        <div style={{padding:"14px 12px 10px",borderBottom:`1px solid ${C.b}`}}>
          <div style={{fontSize:10,fontWeight:700,color:C.d3,textTransform:"uppercase",letterSpacing:"0.8px",marginBottom:8}}>Bantay Benta v4</div>
          <div style={{display:"flex",alignItems:"center",gap:10,background:C.bg3,borderRadius:8,padding:"8px 10px"}}>
            <span style={{fontSize:20}}>{user.emoji}</span>
            <div><div style={{fontSize:12,fontWeight:700,color:"#fff"}}>{user.name}</div><div style={{fontSize:10,color:user.color,fontWeight:700,textTransform:"uppercase"}}>{user.role}</div></div>
          </div>
        </div>
        <nav style={{flex:1,overflowY:"auto",padding:"4px 0"}}>
          {ownerNav.map(n=><SBtn key={n.id} n={n} active={tab===n.id} onClick={()=>{setTab(n.id);setDrawer(false);}}/>)}
          {isAdmin && <><div style={{padding:"10px 12px 4px",fontSize:10,fontWeight:700,color:C.d3,textTransform:"uppercase",letterSpacing:"0.6px"}}>Admin</div>{adminNav.map(n=><SBtn key={n.id} n={n} active={tab===n.id} onClick={()=>{setTab(n.id);setDrawer(false);}}/>)}</>}
        </nav>
        <div style={{padding:"10px 12px",borderTop:`1px solid ${C.b}`}}>
          <div style={{fontSize:10,color:saved?C.d3:C.am,fontWeight:600,marginBottom:6}}>{saved?"✓ Saved · "+(DB.lastSaved()||""):"💾 Saving..."}</div>
          <div style={{display:"flex",gap:6}}>
            <button onClick={()=>setLang(l=>l==="tl"?"en":"tl")} style={{...gBtn(),flex:1}}>🌐 {t.lang}</button>
            <button onClick={()=>setUser(null)} style={{...gBtn(),flex:1,color:C.re}}>🚪</button>
          </div>
        </div>
      </aside>
      <div className="tk-main" style={{flex:1,display:"flex",flexDirection:"column",minWidth:0}}>
        <header style={{background:C.bg1,borderBottom:`1px solid ${C.b}`,padding:"11px 14px",display:"flex",alignItems:"center",gap:10,position:"sticky",top:0,zIndex:30}}>
          <button onClick={()=>setDrawer(o=>!o)} style={{background:"none",border:`1px solid ${C.b2}`,borderRadius:7,padding:"6px 10px",color:C.tx,cursor:"pointer",fontSize:17,lineHeight:1}}>☰</button>
          <div style={{fontSize:15,fontWeight:700,color:"#fff",flex:1}}>{nav(.find(n=>n.id===tab)||{}).icon} {nav(.find(n=>n.id===tab)||{}).label}</div>
          {tab==="inventory"  && <button style={bSt()} onClick={()=>setModal("addProd")}>{t.addProd}</button>}
          {tab==="expenses"   && <button style={bSt()} onClick={()=>setModal("addExp")}>{t.addExp}</button>}
          {tab==="categories" && <button style={bSt()} onClick={()=>setModal("addCat")}>{t.addCat}</button>}
          {tab==="quicksale"  && null}
        </header>
        <main style={{flex:1,padding:"14px",overflowY:"auto",maxWidth:960,margin:"0 auto",width:"100%"}}>
          {tab==="dashboard"  && <DashPage    {...ctx}/>}
          {tab==="quicksale"  && <QuickSale   {...ctx}/>}
          {tab==="sales"      && <SalesPage   {...ctx}/>}
          {tab==="payments"   && <PayPage     {...ctx} togglePaid={ctx.togglePaid} addPartialPayment={ctx.addPartialPayment}/>}
          {tab==="inventory"  && <InvPage     {...ctx}/>}
          {tab==="categories" && <CatsPage    {...ctx}/>}
          {tab==="reorder"    && <ReorderPage {...ctx} adjStock={ctx.adjStock} addExpense={ctx.addExpense} addProduct={ctx.addProduct}/>}
          {tab==="expenses"   && <ExpPage     {...ctx}/>}
          {tab==="reports"    && <ReportPage  {...ctx}/>}
          {tab==="backup"     && <BackupPage  {...ctx}/>}
          {tab==="adminHome"  && <div style={{...colStyle,padding:"20px",textAlign:"center",color:C.d2}}>🛡️ Admin view — coming soon.</div>}
          {tab==="about"      && <AboutPage setShowOnboard={setShowOnboard} setTab={setTab}/>}
          {tab==="bugs"       && <div style={{...colStyle,padding:"20px",textAlign:"center",color:C.d2}}>🐛 Bug tracker — coming soon in hosted version.</div>}
        </main>
      </div>
      {modal==="newSale"   && <SaleModal    {...ctx} onClose={()=>setModal(null)}/>}
      {modal==="addProd"   && <ProdModal    {...ctx} addExpense={ctx.addExpense} onClose={()=>setModal(null)} mode="add"/>}
      {(modal&&modal.type)==="editProd" && <ProdModal {...ctx} addExpense={ctx.addExpense} onClose={()=>setModal(null)} mode="edit" existing={modal.data}/>}
      {modal==="addExp"    && <ExpModal     {...ctx} onClose={()=>setModal(null)}/>}
      {modal==="addCat"    && <CatModal     {...ctx} onClose={()=>setModal(null)} mode="add"/>}
      {(modal&&modal.type)==="editCat" && <CatModal {...ctx} onClose={()=>setModal(null)} mode="edit" existing={modal.data}/>}
      <style>{`
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:4px;height:4px;}
        ::-webkit-scrollbar-track{background:${C.bg0};}
        ::-webkit-scrollbar-thumb{background:${C.b2};border-radius:4px;}
        input,select,textarea{font-family:inherit;color-scheme:dark;}
        button{font-family:inherit;-webkit-tap-highlight-color:transparent;}
        button:active{opacity:0.85;transform:scale(0.97);}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
        @keyframes slideUp{from{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}
        @media(min-width:768px){
          .tk-sb{transform:translateX(0)!important;position:sticky!important;height:100vh;flex-shrink:0;}
          .tk-main{margin-left:0!important;}
        }
      `}</style>
    </div>
  );
}

// ═══════════════════════════════════════════════ ROOT APP
function App() {
  const [user,setUser]=useState(null);
  const [lang,setLang]=useState(()=>DB.get("lang","tl"));
  const [products,setProducts]=useState(()=>DB.get("products",SEED_PRODUCTS));
  const [expenses,setExpenses]=useState(()=>DB.get("expenses",SEED_EXP));
  const [cats,setCats]=useState(()=>DB.get("categories",DEF_CATS.map((n,i)=>({id:i+1,name:n,color:CAT_COLORS[i]||C.bl}))));
  const [saved,setSaved]=useState(true);
  const saveTimer=useRef(null);
  const t=TR[lang]||TR.tl;
  const debounce=(key,val)=>{setSaved(false);clearTimeout(saveTimer.current);saveTimer.current=setTimeout(()=>{DB.set(key,val);setSaved(true);},400);};
  useEffect(()=>{debounce("products",products);},[products]);
  useEffect(()=>{debounce("expenses",expenses);},[expenses]);
  useEffect(()=>{DB.set("categories",cats);},[cats]);
  useEffect(()=>{DB.set("lang",lang);},[lang]);
  useEffect(()=>{
    const run=()=>DB.autoBackup();
    const id=setInterval(run,30*60*1000);
    window.addEventListener("beforeunload",run);
    return()=>{clearInterval(id);window.removeEventListener("beforeunload",run);};
  },[]);
  const restoreData=data=>{DB.restore(data);if(data.products)setProducts(data.products);if(data.expenses)setExpenses(data.expenses);if(data.categories)setCats(data.categories);};
  if(!user) return (
    <ToastProvider>
      <LoginScreen t={t} lang={lang} setLang={setLang} onLogin={setUser}/>
    </ToastProvider>
  );
  return (
    <ToastProvider>
      <Shell t={t} lang={lang} setLang={setLang} user={user} setUser={setUser}
        saved={saved} products={products} setProducts={setProducts}
        expenses={expenses} setExpenses={setExpenses}
        cats={cats} setCats={setCats} restoreData={restoreData}/>
    </ToastProvider>
  );
}

export default App;
