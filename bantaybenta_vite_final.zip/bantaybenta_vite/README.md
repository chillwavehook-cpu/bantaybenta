# 🏪 Bantay Benta — Vite + PWA Build

## Ano ito?
- **React 18** app (walang Babel sa browser)
- **PWA** — ma-install sa home screen ng phone
- **Offline-first** — gumagana kahit walang internet
- **localStorage** — data naka-save sa phone

---

## Build Steps (kailangan: Node.js 18+ at internet)

### 1. Install dependencies
```bash
npm install
```

### 2. Build for production
```bash
npm run build
```
Output: `/dist` folder

### 3. Test locally (optional)
```bash
npm run preview
```

---

## Deploy sa Vercel (dalawang paraan)

### Option A — GitHub (recommended)
1. I-commit ang `/dist` folder sa GitHub
2. Sa Vercel, itakda ang "Root Directory" sa `dist`
3. Auto-deploy sa bawat commit

### Option B — Vercel CLI
```bash
npm install -g vercel
vercel --prod
```

---

## Structure
```
bantaybenta/
├── index.html          ← splash + root div
├── vite.config.js      ← Vite + PWA config
├── package.json
├── public/
│   ├── icon-192.png    ← PWA icon
│   ├── icon-512.png    ← PWA icon
│   ├── favicon.ico
│   └── manifest.json   ← PWA manifest
└── src/
    ├── main.jsx        ← entry point
    └── App.jsx         ← buong app (2600+ lines)
```

---

## PWA Install
Kapag na-deploy na:
1. Buksan sa Chrome/Samsung Browser
2. May lalabas na "Add to Home Screen" banner
3. I-tap → installed na tulad ng real app!

---

## Features
- ⚡ Quick Sale (3 taps)
- 📦 Inventory + Low Stock Alerts
- 💰 COGS tracking (Buo vs Tingi)
- 📋 Utang + Partial Payment
- 📊 Reports (Daily/Weekly/Monthly)
- 💵 Cash Flow vs Profit view
- 💾 Auto-backup every 30 min
- 🔄 Reorder list with stock alerts
- 🏷️ Category management
- 🌐 Filipino + English
